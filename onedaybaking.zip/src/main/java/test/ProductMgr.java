package test;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Vector;

import onedaybaking.DBConnectionMgr;

public class ProductMgr {
	DBConnectionMgr pool;
	
	public ProductMgr() {
		pool = DBConnectionMgr.getInstance();
	}
	
	//상품 불러오기
	public Vector<ProductBean> getAllProduct(String keyField, String keyWord, int start, int cnt, String sdate, String edate) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		Vector<ProductBean> vlist = new Vector<ProductBean>();
		try {
			con = pool.getConnection();
			if (keyWord.trim().equals("") || keyWord == null) {
				if (sdate.trim().equals("") || sdate == null) {
					sql = "select * from product order by num desc limit ?, ?";
					pstmt = con.prepareStatement(sql);
					pstmt.setInt(1, start);
					pstmt.setInt(2, cnt);
				} else {
					sql = "select * from product where udate between ? and ? order by num desc limit ?, ?";
					pstmt = con.prepareStatement(sql);
					pstmt.setString(1, sdate);
					pstmt.setString(2, edate);
					pstmt.setInt(3, start);
					pstmt.setInt(4, cnt);
				}
			} else if (keyWord != null && sdate != null) {
				if (sdate.trim().equals("") || sdate == null) {
					if (keyField.equals("uid")) {
						sql = "select * from product where " + keyField + " = ? order by num desc limit ?, ?";
						pstmt = con.prepareStatement(sql);
						pstmt.setString(1, keyWord);
						pstmt.setInt(2, start);
						pstmt.setInt(3, cnt);
					} else {
						sql = "select * from product where " + keyField + " like ? order by num desc limit ?, ?";
						pstmt = con.prepareStatement(sql);
						pstmt.setString(1, "%" + keyWord + "%");
						pstmt.setInt(2, start);
						pstmt.setInt(3, cnt);
					}
				} else {
					sql = "select * from product where " + keyField + " = ?  and udate between ? and ? order by num desc limit ?, ?";
					pstmt = con.prepareStatement(sql);
					pstmt.setString(1, keyWord);
					pstmt.setString(2, sdate);
					pstmt.setString(3, edate);
					pstmt.setInt(4, start);
					pstmt.setInt(5, cnt);
				}
			}
			rs = pstmt.executeQuery();
			while (rs.next()) {
				ProductBean bean = new ProductBean();
				bean.setNum(rs.getInt(1));
				bean.setUname(rs.getString(2));
				bean.setPname(rs.getString(3));
				bean.setPrice(rs.getInt(4));
				bean.setUid(rs.getString(5));
				bean.setUdate(rs.getString(6));
				bean.setDel(rs.getString(7));
				vlist.addElement(bean);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt, rs);
		}
		return vlist;
	}
	
	//상품 전체 개수
	public int getTotalCount(String keyField, String keyWord, String sdate, String edate) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		int totalCount = 0;
		try {
			con = pool.getConnection();
			if (keyWord.trim().equals("") || keyWord == null) {
				if (sdate.trim().equals("") || sdate == null) {
					sql = "select count(*) from product";
					pstmt = con.prepareStatement(sql);
				} else {
					sql = "select count(*) from product where udate between ? and ?";
					pstmt = con.prepareStatement(sql);
					pstmt.setString(1, sdate);
					pstmt.setString(2, edate);
				}
			} else if (keyWord != null && sdate != null) {
				if (sdate.trim().equals("") || sdate == null) {
					if (keyField.equals("uid")) {
						sql = "select count(*) from product where " + keyField + " = ?";
						pstmt = con.prepareStatement(sql);
						pstmt.setString(1, keyWord);
					} else {
						sql = "select count(*) from product where " + keyField + " like ?";
						pstmt = con.prepareStatement(sql);
						pstmt.setString(1, "%" + keyWord + "%");
					}
				} else {
					sql = "select count(*) from product where " + keyField + " = ?  and udate between ? and ?";
					pstmt = con.prepareStatement(sql);
					pstmt.setString(1, keyWord);
					pstmt.setString(2, sdate);
					pstmt.setString(3, edate);
				}
			}
			rs = pstmt.executeQuery();
			if (rs.next()) totalCount = rs.getInt(1);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt, rs);
		}
		return totalCount;
	}

	public void insertProduct() {
		Connection con = null;
		PreparedStatement pstmt = null;
		String sql = null;
		try {
			con = pool.getConnection();
			sql = "insert into product values(null, ?, ?, ?, ?, ?, ?)";
			pstmt = con.prepareStatement(sql);
			String[] name = {"김자바", "최자바", "김삼성", "박삼성", "최나리", "김나리"};
			String[] pro = {"1번상품", "2번은 개인주의야", "3번 상상", "4번품품", "5번 감감", "6번ㅁㅁ"};
			String[] ids = {"id1", "id2", "id3", "id4", "id5", "id6"};
			String[] dates = {"2024-03-03", "2024-03-28", "2024-02-22", "2024-05-03", "2024-01-03", "2024-02-03"};
			for (int i = 0; i < 5; i++) {
				for (int j = 0; j < name.length; j++) {
					pstmt.setString(1, name[j]);
					pstmt.setString(2, pro[j]);
					pstmt.setInt(3, 5000);
					pstmt.setString(4, ids[j]);
					pstmt.setString(5, dates[j]);
					pstmt.setString(6, "N");
					pstmt.executeUpdate();
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt);
		}
	}
	
	public static void main(String[] args) {
		ProductMgr pmgr = new ProductMgr();
		pmgr.insertProduct();
		System.out.println("완료");
	}
}