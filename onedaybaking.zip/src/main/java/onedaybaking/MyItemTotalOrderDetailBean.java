package onedaybaking;

public class MyItemTotalOrderDetailBean {
	private int totalOrderKey;
	private int itemOrderKey;
	private String orderCard;
	private int totalPrice;
	private int couponPrice;
	private int orderPrice;
	private String orderName;
	private String orderPhone;
	private String address;
	private String addressDetail;
	private String orderRequest;
	private String itemOrderDate;
	
	public int getTotalOrderKey() {
		return totalOrderKey;
	}
	public void setTotalOrderKey(int totalOrderKey) {
		this.totalOrderKey = totalOrderKey;
	}
	public int getItemOrderKey() {
		return itemOrderKey;
	}
	public void setItemOrderKey(int itemOrderKey) {
		this.itemOrderKey = itemOrderKey;
	}
	public String getOrderCard() {
		return orderCard;
	}
	public void setOrderCard(String orderCard) {
		this.orderCard = orderCard;
	}
	public int getTotalPrice() {
		return totalPrice;
	}
	public void setTotalPrice(int totalPrice) {
		this.totalPrice = totalPrice;
	}
	public int getCouponPrice() {
		return couponPrice;
	}
	public void setCouponPrice(int couponPrice) {
		this.couponPrice = couponPrice;
	}
	public int getOrderPrice() {
		return orderPrice;
	}
	public void setOrderPrice(int orderPrice) {
		this.orderPrice = orderPrice;
	}
	public String getOrderName() {
		return orderName;
	}
	public void setOrderName(String orderName) {
		this.orderName = orderName;
	}
	public String getOrderPhone() {
		return orderPhone;
	}
	public void setOrderPhone(String orderPhone) {
		this.orderPhone = orderPhone;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getAddressDetail() {
		return addressDetail;
	}
	public void setAddressDetail(String addressDetail) {
		this.addressDetail = addressDetail;
	}
	public String getOrderRequest() {
		return orderRequest;
	}
	public void setOrderRequest(String orderRequest) {
		this.orderRequest = orderRequest;
	}
	public String getItemOrderDate() {
		return itemOrderDate;
	}
	public void setItemOrderDate(String itemOrderDate) {
		this.itemOrderDate = itemOrderDate;
	}
	
}
