package onedaybaking;
	
	public class CateBean {
		private int categorykey;
		private String categorygroup;
		private String categoryname;
		public int getCategorykey() {
			return categorykey;
		}
		public void setCategorykey(int categorykey) {
			this.categorykey = categorykey;
		}
		public String getCategorygroup() {
			return categorygroup;
		}
		public void setCategorygroup(String categorygroup) {
			this.categorygroup = categorygroup;
		}
		public String getCategoryname() {
			return categoryname;
		}
		public void setCategoryname(String categoryname) {
			this.categoryname = categoryname;
		}
	}
