package onedaybaking;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Vector;

public class TeacherMgr {
	DBConnectionMgr pool;
	
	public TeacherMgr() {
		pool = DBConnectionMgr.getInstance();
	}
	
	//강사가 등록한 상품 리스트
	public Vector<ItemBean> teacherItemList(String memberId) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		Vector<ItemBean> vlist = new Vector<ItemBean>();
		try {
			con = pool.getConnection();
			sql = "select * from item a "
					+ "left outer join member c on a.memberid = c.memberid "
					+ "where a.memberId = ? order by a.itemkey desc";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, memberId);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				ItemBean bean = new ItemBean();
				bean.setItemkey(rs.getInt("itemKey"));
				bean.setMembername(rs.getString("membernick"));
				bean.setItemname(rs.getString("itemname"));
				bean.setItemprice(rs.getInt("itemprice"));
				bean.setItemimg(rs.getString("itemimg"));
				vlist.addElement(bean);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt, rs);
		}
		return vlist;
	}
	
	//강사가 등록한 클래스 리스트
	public Vector<ClassBean> teacherClassList(String memberId) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		Vector<ClassBean> vlist = new Vector<ClassBean>();
		try {
			con = pool.getConnection();
			sql = "select * from class a "
					+ "left outer join member c on a.memberid = c.memberid "
					+ "where a.memberId = ? order by a.classkey desc";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, memberId);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				ClassBean bean = new ClassBean();
				bean.setClasskey(rs.getInt("classKey"));
				bean.setMembername(rs.getString("membernick"));
				bean.setClassname(rs.getString("classname"));
				bean.setClassprice(rs.getInt("classprice"));
				bean.setClassimg1(rs.getString("classimg1"));
				bean.setAddress(rs.getString("address"));
				vlist.addElement(bean);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt, rs);
		}
		return vlist;
	}
}
