package onedaybaking;

public class CouponBean {
	private int couponKey;
	private String couponName;
	private int couponPrice;
	private String couponDown;
	private String couponClose;
	private String couponStatus;
	private String memberId;
	
	public int getCouponKey() {
		return couponKey;
	}
	public void setCouponKey(int couponKey) {
		this.couponKey = couponKey;
	}
	public String getCouponName() {
		return couponName;
	}
	public void setCouponName(String couponName) {
		this.couponName = couponName;
	}
	public int getCouponPrice() {
		return couponPrice;
	}
	public void setCouponPrice(int couponPrice) {
		this.couponPrice = couponPrice;
	}
	public String getCouponDown() {
		return couponDown;
	}
	public void setCouponDown(String couponDown) {
		this.couponDown = couponDown;
	}
	public String getCouponClose() {
		return couponClose;
	}
	public void setCouponClose(String couponClose) {
		this.couponClose = couponClose;
	}
	public String getCouponStatus() {
		return couponStatus;
	}
	public void setCouponStatus(String couponStatus) {
		this.couponStatus = couponStatus;
	}
	public String getMemberId() {
		return memberId;
	}
	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}
	
	
}
