package onedaybaking;

public class ItemOptionBean {
	private int optionKey;
	private String itemOption1;
	private String itemOption2;
	private String itemOption3;
	private String itemOption4;
	private String itemOption5;
	private String itemOption6;
	private String itemOption7;
	private String itemOption8;
	private String itemOption9;
	private String itemOption10;
	private String itemsOption1;
	private String itemsOption2;
	private String itemsOption3;
	private String itemsOption4;
	private String itemsOption5;
	private String itemsOption6;
	private String itemsOption7;
	private String itemsOption8;
	private String itemsOption9;
	private String itemsOption10;
	private int itemKey;
	
	public int getOptionKey() {
		return optionKey;
	}
	public void setOptionKey(int optionKey) {
		this.optionKey = optionKey;
	}
	public String getItemOption1() {
		return itemOption1;
	}
	public void setItemOption1(String itemOption1) {
		this.itemOption1 = itemOption1;
	}
	public String getItemOption2() {
		return itemOption2;
	}
	public void setItemOption2(String itemOption2) {
		this.itemOption2 = itemOption2;
	}
	public String getItemOption3() {
		return itemOption3;
	}
	public void setItemOption3(String itemOption3) {
		this.itemOption3 = itemOption3;
	}
	public String getItemOption4() {
		return itemOption4;
	}
	public void setItemOption4(String itemOption4) {
		this.itemOption4 = itemOption4;
	}
	public String getItemOption5() {
		return itemOption5;
	}
	public void setItemOption5(String itemOption5) {
		this.itemOption5 = itemOption5;
	}
	public String getItemOption6() {
		return itemOption6;
	}
	public void setItemOption6(String itemOption6) {
		this.itemOption6 = itemOption6;
	}
	public String getItemOption7() {
		return itemOption7;
	}
	public void setItemOption7(String itemOption7) {
		this.itemOption7 = itemOption7;
	}
	public String getItemOption8() {
		return itemOption8;
	}
	public void setItemOption8(String itemOption8) {
		this.itemOption8 = itemOption8;
	}
	public String getItemOption9() {
		return itemOption9;
	}
	public void setItemOption9(String itemOption9) {
		this.itemOption9 = itemOption9;
	}
	public String getItemOption10() {
		return itemOption10;
	}
	public void setItemOption10(String itemOption10) {
		this.itemOption10 = itemOption10;
	}
	public String getItemsOption1() {
		return itemsOption1;
	}
	public void setItemsOption1(String itemsOption1) {
		this.itemsOption1 = itemsOption1;
	}
	public String getItemsOption2() {
		return itemsOption2;
	}
	public void setItemsOption2(String itemsOption2) {
		this.itemsOption2 = itemsOption2;
	}
	public String getItemsOption3() {
		return itemsOption3;
	}
	public void setItemsOption3(String itemsOption3) {
		this.itemsOption3 = itemsOption3;
	}
	public String getItemsOption4() {
		return itemsOption4;
	}
	public void setItemsOption4(String itemsOption4) {
		this.itemsOption4 = itemsOption4;
	}
	public String getItemsOption5() {
		return itemsOption5;
	}
	public void setItemsOption5(String itemsOption5) {
		this.itemsOption5 = itemsOption5;
	}
	public String getItemsOption6() {
		return itemsOption6;
	}
	public void setItemsOption6(String itemsOption6) {
		this.itemsOption6 = itemsOption6;
	}
	public String getItemsOption7() {
		return itemsOption7;
	}
	public void setItemsOption7(String itemsOption7) {
		this.itemsOption7 = itemsOption7;
	}
	public String getItemsOption8() {
		return itemsOption8;
	}
	public void setItemsOption8(String itemsOption8) {
		this.itemsOption8 = itemsOption8;
	}
	public String getItemsOption9() {
		return itemsOption9;
	}
	public void setItemsOption9(String itemsOption9) {
		this.itemsOption9 = itemsOption9;
	}
	public String getItemsOption10() {
		return itemsOption10;
	}
	public void setItemsOption10(String itemsOption10) {
		this.itemsOption10 = itemsOption10;
	}
	public int getItemKey() {
		return itemKey;
	}
	public void setItemKey(int itemKey) {
		this.itemKey = itemKey;
	}
	
	
	
}
