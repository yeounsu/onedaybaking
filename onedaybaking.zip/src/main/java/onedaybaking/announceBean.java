package onedaybaking;

public class announceBean {

	private int announceNum;
	
	private String announceSubject;

	private String announceContent;
	
	private String announceWriter;
	
	private String announceDay;
	
	private int announceView;
	
	private String announceFile;
	
	
	public int getAnnounceNum() {
		return announceNum;
	}

	public void setAnnounceNum(int announceNum) {
		this.announceNum = announceNum;
	}

	public String getAnnounceSubject() {
		return announceSubject;
	}

	public void setAnnounceSubject(String announceSubject) {
		this.announceSubject = announceSubject;
	}

	public String getAnnounceContent() {
		return announceContent;
	}

	public void setAnnounceContent(String announceContent) {
		this.announceContent = announceContent;
	}

	public String getAnnounceWriter() {
		return announceWriter;
	}

	public void setAnnounceWriter(String announceWriter) {
		this.announceWriter = announceWriter;
	}

	public String getAnnounceDay() {
		return announceDay;
	}

	public void setAnnounceDay(String announceDay) {
		this.announceDay = announceDay;
	}

	public int getAnnounceView() {
		return announceView;
	}

	public void setAnnounceView(int announceView) {
		this.announceView = announceView;
	}

	public String getAnnounceFile() {
		return announceFile;
	}

	public void setAnnounceFile(String announceFile) {
		this.announceFile = announceFile;
	}

}
