package onedaybaking;

public class MyclassBean {

	private int classKey;
	
	private String classname;
	
	private String memberName;
	
	private String memberPhone;
	
	private int classtotal;
	
	

	public int getClassKey() {
		return classKey;
	}

	public void setClassKey(int classKey) {
		this.classKey = classKey;
	}
	
	public String getClassname() {
		return classname;
	}

	public void setClassname(String clssname) {
		this.classname = clssname;
	}

	public String getMemberName() {
		return memberName;
	}

	public void setMemberName(String memberName) {
		this.memberName = memberName;
	}

	public String getMemberPhone() {
		return memberPhone;
	}

	public void setMemberPhone(String memberPhone) {
		this.memberPhone = memberPhone;
	}

	public int getClasstotal() {
		return classtotal;
	}

	public void setClasstotal(int classtotal) {
		this.classtotal = classtotal;
	}
	
}
