
package onedaybaking;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

public class AdmingetClassMgr {
	DBConnectionMgr pool;
	public AdmingetClassMgr() {
		pool = DBConnectionMgr.getInstance();
	}

	
	//클래스 신청 갯수 (개인)
	public int getapplicationclass(String id) {
	    Connection con = null;
	    PreparedStatement pstmt = null;
	    ResultSet rs = null;
	    String sql = null;
	    int count = 0;
	    try {
	        con = pool.getConnection();
	       
	        sql = "SELECT COUNT(*) FROM class WHERE classdelete = 'N'";
	        pstmt = con.prepareStatement(sql);
	        rs = pstmt.executeQuery();
	        if (rs.next()) {
	            count = rs.getInt(1);
	        }
	    } catch (Exception e) {
	        e.printStackTrace();
	    } finally {
	        pool.freeConnection(con, pstmt, rs);
	    }
	    return count;
	}

	
	//클래스 신청 리스트
	public Vector<ClassBean> admingetWishItemList(String id) {
	    Connection con = null;
	    PreparedStatement pstmt = null;
	    ResultSet rs = null;
	    String sql = null;
	    Vector<ClassBean> vlist = new Vector<ClassBean>();
	    try {
	        con = pool.getConnection();
	        sql = "SELECT * FROM class where classdelete = 'N' ";
	        pstmt = con.prepareStatement(sql);
	        
	        rs = pstmt.executeQuery();
	        while (rs.next()) {
	            ClassBean bean = new ClassBean();
	            bean.setClasskey(rs.getInt("classKey"));
	            bean.setClassimg1(rs.getString("classimg1"));
	            bean.setClassteacherinfo(rs.getString("classteacherinfo"));
	            bean.setClassname(rs.getString("classname"));
	            bean.setClassdelete(rs.getString("classdelete"));
	            bean.setClassprice(rs.getInt("classprice"));
	            vlist.addElement(bean);
	        }
	    } catch (Exception e) {
	        e.printStackTrace();
	    } finally {
	        pool.freeConnection(con, pstmt, rs);
	    }
	    return vlist;
	}
	
	 public Vector<ClassBean> getAllClassList() {
	        Connection con = null;
	        PreparedStatement pstmt = null;
	        ResultSet rs = null;
	        String sql = null;
	        Vector<ClassBean> vlist = new Vector<ClassBean>();
	        try {
	            con = pool.getConnection();
	            sql = "SELECT * FROM class";
	            pstmt = con.prepareStatement(sql);
	            rs = pstmt.executeQuery();
	            while (rs.next()) {
	                ClassBean bean = new ClassBean();
	                bean.setClasskey(rs.getInt("classKey"));
	                bean.setClassname(rs.getString("classname"));
	                bean.setClassdate(rs.getString("classdate"));
	                bean.setClassmin(rs.getInt("classmin"));
	                bean.setClassmax(rs.getInt("classmax"));
	                bean.setClassprice(rs.getInt("classprice"));
	                bean.setClasslevel(rs.getString("classlevel"));
	                bean.setClasstime(rs.getInt("classtime"));
	                bean.setAddress(rs.getString("address"));
	                bean.setAddressdetail(rs.getString("addressdetail"));
	                // 배열 형태로 저장된 데이터를 가져옵니다.
	                String[] classStatusArray = rs.getString("classstatus").split(","); // 쉼표(,)를 기준으로 배열로 분할합니다.
	                bean.setClassstatus(classStatusArray); // 분할된 배열을 설정합니다.
	                bean.setClassdelete(rs.getString("classdelete"));
	                bean.setClassteacherinfo(rs.getString("classteacherinfo"));
	                bean.setClassteacherimg(rs.getString("classteacherimg"));
	                bean.setClassimg1(rs.getString("classimg1"));
	                bean.setClassimg2(rs.getString("classimg2"));
	                bean.setClassimg3(rs.getString("classimg3"));
	                bean.setClassimg4(rs.getString("classimg4"));
	                bean.setClassimg5(rs.getString("classimg5"));
	                bean.setClasscontent(rs.getString("classcontent"));
	                bean.setRoomimg1(rs.getString("roomimg1"));
	                bean.setRoomimg2(rs.getString("roomimg2"));
	                bean.setMemberid(rs.getString("memberid"));
	                bean.setCategorykey(rs.getInt("categorykey"));
	                bean.setClassteachername(rs.getString("classteachername"));
	                vlist.addElement(bean);
	            }
	        } catch (Exception e) {
	            e.printStackTrace();
	        } finally {
	            pool.freeConnection(con, pstmt, rs);
	        }
	        return vlist;
	    }
	 public int getCatekey() {
			Connection con = null;
			PreparedStatement pstmt = null;
			ResultSet rs = null;
			String sql = null;
			int num = 0;
			try {
				con = pool.getConnection();
				sql = "select * from category order by categorykey desc";
				pstmt = con.prepareStatement(sql);
				rs = pstmt.executeQuery();
				if (rs.next()) num = rs.getInt(1);
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				pool.freeConnection(con, pstmt, rs);
			}
			return num;
		}

	 public ClassBean getClassInfoByClassKey(int classkey) {
		    Connection con = null;
		    PreparedStatement pstmt = null;
		    ResultSet rs = null;
		    String sql = null;
		    ClassBean bean = null;

		    try {
		        con = pool.getConnection();
		        sql = "SELECT * FROM class c INNER JOIN category cat ON c.categorykey = cat.categorykey WHERE c.classkey = ?";
		        pstmt = con.prepareStatement(sql);
		        pstmt.setInt(1, classkey);
		        rs = pstmt.executeQuery();

		        if (rs.next()) {
		            bean = new ClassBean();
		            // Set class fields
		            bean.setClasskey(rs.getInt("classKey"));
		            bean.setClassname(rs.getString("classname"));
		            bean.setClassdate(rs.getString("classdate"));
		            bean.setClassmin(rs.getInt("classmin"));
		            bean.setClassmax(rs.getInt("classmax"));
		            bean.setClassprice(rs.getInt("classprice"));
		            bean.setClasslevel(rs.getString("classlevel"));
		            bean.setClasstime(rs.getInt("classtime"));
		            bean.setAddress(rs.getString("address"));
		            bean.setAddressdetail(rs.getString("addressdetail"));
		            String option = rs.getString("classstatus");
		            String os[] = new String[option.length()];
		            for (int i = 0; i < os.length; i++) {
		               os[i] = option.substring(i, i + 1);
		            }
		            bean.setClassstatus(os);
		            bean.setClassdelete(rs.getString("classdelete"));
		            bean.setClassteacherinfo(rs.getString("classteacherinfo"));
		            bean.setClassteacherimg(rs.getString("classteacherimg"));
		            bean.setClassimg1(rs.getString("classimg1"));
		            bean.setClassimg2(rs.getString("classimg2"));
		            bean.setClassimg3(rs.getString("classimg3"));
		            bean.setClassimg4(rs.getString("classimg4"));
		            bean.setClassimg5(rs.getString("classimg5"));
		            bean.setClasscontent(rs.getString("classcontent"));
		            bean.setRoomimg1(rs.getString("roomimg1"));
		            bean.setRoomimg2(rs.getString("roomimg2"));
		            bean.setMemberid(rs.getString("memberid"));
		            bean.setCategorykey(rs.getInt("categorykey"));
		            bean.setClassteachername(rs.getString("classteachername"));

		            // Set category fields
		            categoryBean categoryBean = new categoryBean();
		            categoryBean.setCategorykey(rs.getInt("categorykey"));
		            categoryBean.setCategorygroup(rs.getString("categorygroup"));
		            categoryBean.setCategoryname(rs.getString("categoryname"));

		            bean.setCategoryBean(categoryBean);
		        }
		    } catch (Exception e) {
		        e.printStackTrace();
		    } finally {
		        pool.freeConnection(con, pstmt, rs);
		    }

		    return bean;
		}
	 public List<ClassBean> getClassInfoByCookie() {
		    Connection con = null;
		    PreparedStatement pstmt = null;
		    ResultSet rs = null;
		    String sql = null;
		    List<ClassBean> classList = new ArrayList<>();

		    try {
		        con = pool.getConnection();
		        sql = "SELECT * FROM class c INNER JOIN category cat ON c.categorykey = cat.categorykey WHERE cat.categorygroup = '제과'";
		        pstmt = con.prepareStatement(sql);
		        
		        rs = pstmt.executeQuery();

		        while (rs.next()) {
		            ClassBean bean = new ClassBean();
		            // Set class fields
		            bean.setClasskey(rs.getInt("classKey"));
		            bean.setClassname(rs.getString("classname"));
		            bean.setClassdate(rs.getString("classdate"));
		            bean.setClassmin(rs.getInt("classmin"));
		            bean.setClassmax(rs.getInt("classmax"));
		            bean.setClassprice(rs.getInt("classprice"));
		            bean.setClasslevel(rs.getString("classlevel"));
		            bean.setClasstime(rs.getInt("classtime"));
		            bean.setAddress(rs.getString("address"));
		            bean.setAddressdetail(rs.getString("addressdetail"));
		            String option = rs.getString("classstatus");
		            String os[] = new String[option.length()];
		            for (int i = 0; i < os.length; i++) {
		                os[i] = option.substring(i, i + 1);
		            }
		            bean.setClassstatus(os);
		            bean.setClassdelete(rs.getString("classdelete"));
		            bean.setClassteacherinfo(rs.getString("classteacherinfo"));
		            bean.setClassteacherimg(rs.getString("classteacherimg"));
		            bean.setClassimg1(rs.getString("classimg1"));
		            bean.setClassimg2(rs.getString("classimg2"));
		            bean.setClassimg3(rs.getString("classimg3"));
		            bean.setClassimg4(rs.getString("classimg4"));
		            bean.setClassimg5(rs.getString("classimg5"));
		            bean.setClasscontent(rs.getString("classcontent"));
		            bean.setRoomimg1(rs.getString("roomimg1"));
		            bean.setRoomimg2(rs.getString("roomimg2"));
		            bean.setMemberid(rs.getString("memberid"));
		            bean.setCategorykey(rs.getInt("categorykey"));
		            bean.setClassteachername(rs.getString("classteachername"));

		            // Set category fields
		            categoryBean categoryBean = new categoryBean();
		            categoryBean.setCategorykey(rs.getInt("categorykey"));
		            categoryBean.setCategorygroup(rs.getString("categorygroup"));
		            categoryBean.setCategoryname(rs.getString("categoryname"));

		            bean.setCategoryBean(categoryBean);

		            // Add bean to the list
		            classList.add(bean);
		        }
		    } catch (Exception e) {
		        e.printStackTrace();
		    } finally {
		        pool.freeConnection(con, pstmt, rs);
		    }

		    return classList;
		}
	 public List<ClassBean> getClassInfoBybread() {
		    Connection con = null;
		    PreparedStatement pstmt = null;
		    ResultSet rs = null;
		    String sql = null;
		    List<ClassBean> classList = new ArrayList<>();

		    try {
		        con = pool.getConnection();
		        sql = "SELECT * FROM class c INNER JOIN category cat ON c.categorykey = cat.categorykey WHERE cat.categorygroup = '제빵'";
		        pstmt = con.prepareStatement(sql);
		        
		        rs = pstmt.executeQuery();

		        while (rs.next()) {
		            ClassBean bean = new ClassBean();
		            // Set class fields
		            bean.setClasskey(rs.getInt("classKey"));
		            bean.setClassname(rs.getString("classname"));
		            bean.setClassdate(rs.getString("classdate"));
		            bean.setClassmin(rs.getInt("classmin"));
		            bean.setClassmax(rs.getInt("classmax"));
		            bean.setClassprice(rs.getInt("classprice"));
		            bean.setClasslevel(rs.getString("classlevel"));
		            bean.setClasstime(rs.getInt("classtime"));
		            bean.setAddress(rs.getString("address"));
		            bean.setAddressdetail(rs.getString("addressdetail"));
		            String option = rs.getString("classstatus");
		            String os[] = new String[option.length()];
		            for (int i = 0; i < os.length; i++) {
		                os[i] = option.substring(i, i + 1);
		            }
		            bean.setClassstatus(os);
		            bean.setClassdelete(rs.getString("classdelete"));
		            bean.setClassteacherinfo(rs.getString("classteacherinfo"));
		            bean.setClassteacherimg(rs.getString("classteacherimg"));
		            bean.setClassimg1(rs.getString("classimg1"));
		            bean.setClassimg2(rs.getString("classimg2"));
		            bean.setClassimg3(rs.getString("classimg3"));
		            bean.setClassimg4(rs.getString("classimg4"));
		            bean.setClassimg5(rs.getString("classimg5"));
		            bean.setClasscontent(rs.getString("classcontent"));
		            bean.setRoomimg1(rs.getString("roomimg1"));
		            bean.setRoomimg2(rs.getString("roomimg2"));
		            bean.setMemberid(rs.getString("memberid"));
		            bean.setCategorykey(rs.getInt("categorykey"));
		            bean.setClassteachername(rs.getString("classteachername"));

		            // Set category fields
		            categoryBean categoryBean = new categoryBean();
		            categoryBean.setCategorykey(rs.getInt("categorykey"));
		            categoryBean.setCategorygroup(rs.getString("categorygroup"));
		            categoryBean.setCategoryname(rs.getString("categoryname"));

		            bean.setCategoryBean(categoryBean);

		            // Add bean to the list
		            classList.add(bean);
		        }
		    } catch (Exception e) {
		        e.printStackTrace();
		    } finally {
		        pool.freeConnection(con, pstmt, rs);
		    }

		    return classList;
		}
	 public List<ClassBean> getClassInfoByCoffee() {
		    Connection con = null;
		    PreparedStatement pstmt = null;
		    ResultSet rs = null;
		    String sql = null;
		    List<ClassBean> classList = new ArrayList<>();

		    try {
		        con = pool.getConnection();
		        sql = "SELECT * FROM class c INNER JOIN category cat ON c.categorykey = cat.categorykey WHERE cat.categorygroup = '커피'";
		        pstmt = con.prepareStatement(sql);
		        
		        rs = pstmt.executeQuery();

		        while (rs.next()) {
		            ClassBean bean = new ClassBean();
		            // Set class fields
		            bean.setClasskey(rs.getInt("classKey"));
		            bean.setClassname(rs.getString("classname"));
		            bean.setClassdate(rs.getString("classdate"));
		            bean.setClassmin(rs.getInt("classmin"));
		            bean.setClassmax(rs.getInt("classmax"));
		            bean.setClassprice(rs.getInt("classprice"));
		            bean.setClasslevel(rs.getString("classlevel"));
		            bean.setClasstime(rs.getInt("classtime"));
		            bean.setAddress(rs.getString("address"));
		            bean.setAddressdetail(rs.getString("addressdetail"));
		            String option = rs.getString("classstatus");
		            String os[] = new String[option.length()];
		            for (int i = 0; i < os.length; i++) {
		                os[i] = option.substring(i, i + 1);
		            }
		            bean.setClassstatus(os);
		            bean.setClassdelete(rs.getString("classdelete"));
		            bean.setClassteacherinfo(rs.getString("classteacherinfo"));
		            bean.setClassteacherimg(rs.getString("classteacherimg"));
		            bean.setClassimg1(rs.getString("classimg1"));
		            bean.setClassimg2(rs.getString("classimg2"));
		            bean.setClassimg3(rs.getString("classimg3"));
		            bean.setClassimg4(rs.getString("classimg4"));
		            bean.setClassimg5(rs.getString("classimg5"));
		            bean.setClasscontent(rs.getString("classcontent"));
		            bean.setRoomimg1(rs.getString("roomimg1"));
		            bean.setRoomimg2(rs.getString("roomimg2"));
		            bean.setMemberid(rs.getString("memberid"));
		            bean.setCategorykey(rs.getInt("categorykey"));
		            bean.setClassteachername(rs.getString("classteachername"));

		            // Set category fields
		            categoryBean categoryBean = new categoryBean();
		            categoryBean.setCategorykey(rs.getInt("categorykey"));
		            categoryBean.setCategorygroup(rs.getString("categorygroup"));
		            categoryBean.setCategoryname(rs.getString("categoryname"));

		            bean.setCategoryBean(categoryBean);

		            // Add bean to the list
		            classList.add(bean);
		        }
		    } catch (Exception e) {
		        e.printStackTrace();
		    } finally {
		        pool.freeConnection(con, pstmt, rs);
		    }

		    return classList;
		}
	 
	 public boolean updateClassDelete(int classkey) {
		    Connection con = null;
		    PreparedStatement pstmt = null;
		    String sql = null;
		    boolean flag = false;
		    try {
		        con = pool.getConnection();
		        sql = "UPDATE class SET classdelete='Y' WHERE classkey=?";
		        pstmt = con.prepareStatement(sql);
		        pstmt.setInt(1, classkey);
		        if (pstmt.executeUpdate() == 1) {
		            flag = true;
		        }
		    } catch (Exception e) {
		        e.printStackTrace();
		    } finally {
		        pool.freeConnection(con, pstmt);
		    }
		    return flag;
		}
	 
	 public boolean updatetwoClassDelete(int classkey) {
		    Connection con = null;
		    PreparedStatement pstmt = null;
		    String sql = null;
		    boolean flag = false;
		    try {
		        con = pool.getConnection();
		        sql = "UPDATE class SET classdelete='R' WHERE classkey=?";
		        pstmt = con.prepareStatement(sql);
		        pstmt.setInt(1, classkey);
		        if (pstmt.executeUpdate() == 1) {
		            flag = true;
		        }
		    } catch (Exception e) {
		        e.printStackTrace();
		    } finally {
		        pool.freeConnection(con, pstmt);
		    }
		    return flag;
		}
		
		

}