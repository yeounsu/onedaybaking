package onedaybaking;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Vector;

public class ListMgr {
	DBConnectionMgr pool;
	
	public ListMgr() {
		pool = DBConnectionMgr.getInstance();
	}
	
	//아이템 리스트 불러오기
	public Vector<ListBean> getItemList() {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		Vector<ListBean> vlist = new Vector<ListBean>();
		try {
			con = pool.getConnection();
			sql = "select * from item a left outer join member b on a.memberid = b.memberid where itemdelete = 'N' order by rand() limit 0, 3";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while (rs.next() ) {
				ListBean bean = new ListBean();
				bean.setKey(rs.getInt("itemkey"));
				bean.setMemberid(rs.getString("memberid"));
				bean.setMembernick(rs.getString("membernick"));
				bean.setName(rs.getString("itemname"));
				bean.setPrice(rs.getInt("itemprice"));
				bean.setImg1(rs.getString("itemimg"));
				bean.setMemberimg(rs.getString("memberinfoimg"));
				vlist.addElement(bean);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt, rs);
		}
		return vlist;
	}
	
	//아이템 리스트 불러오기
	public Vector<ListBean> getItemList(String word) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		Vector<ListBean> vlist = new Vector<ListBean>();
		try {
			con = pool.getConnection();
			sql = "select * from item a left outer join member b on a.memberid = b.memberid where itemdelete = 'N' and itemname like ? order by rand()";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, "%" + word + "%");
			rs = pstmt.executeQuery();
			while (rs.next()) {
				ListBean bean = new ListBean();
				bean.setKey(rs.getInt("itemkey"));
				bean.setMemberid(rs.getString("memberid"));
				bean.setMembernick(rs.getString("membernick"));
				bean.setName(rs.getString("itemname"));
				bean.setPrice(rs.getInt("itemprice"));
				bean.setImg1(rs.getString("itemimg"));
				bean.setMemberimg(rs.getString("memberinfoimg"));
				vlist.addElement(bean);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt, rs);
		}
		return vlist;
	}
	
	//모든 아이템 리스트 불러오기
	public Vector<ListBean> getAllItemList() {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		Vector<ListBean> vlist = new Vector<ListBean>();
		try {
			con = pool.getConnection();
			sql = "select * from item a left outer join member b on a.memberid = b.memberid where itemdelete = 'N' order by a.itemkey desc";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				ListBean bean = new ListBean();
				bean.setKey(rs.getInt("itemkey"));
				bean.setMemberid(rs.getString("memberid"));
				bean.setMembernick(rs.getString("membernick"));
				bean.setName(rs.getString("itemname"));
				bean.setPrice(rs.getInt("itemprice"));
				bean.setImg1(rs.getString("itemimg"));
				bean.setMemberimg(rs.getString("memberinfoimg"));
				vlist.addElement(bean);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt, rs);
		}
		return vlist;
	}
	
	//모든 아이템 개수
	public int getItemListCount() {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		int count = 0;
		try {
			con = pool.getConnection();
			sql = "select count(*) from item where itemdelete = 'N'";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			if (rs.next()) count = rs.getInt(1);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt, rs);
		}
		return count;
	}
	
	//카테고리 별 아이템 리스트 가져오기
	public Vector<ListBean> getCateItemList(String category) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		Vector<ListBean> vlist = new Vector<ListBean>();
		try {
			con = pool.getConnection();
			sql = "select * from item a "
					+ "left outer join category b on a.categorykey = b.categorykey "
					+ "left outer join member c on a.memberid = c.memberid "
					+ "where itemdelete = 'N' and b.categorygroup = ? order by a.itemkey desc";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, category);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				ListBean bean = new ListBean();
				bean.setKey(rs.getInt("itemkey"));
				bean.setMemberid(rs.getString("memberid"));
				bean.setMembernick(rs.getString("membernick"));
				bean.setName(rs.getString("itemname"));
				bean.setPrice(rs.getInt("itemprice"));
				bean.setImg1(rs.getString("itemimg"));
				bean.setMemberimg(rs.getString("memberinfoimg"));
				vlist.addElement(bean);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt, rs);
		}
		return vlist;
	}
	
	//카테고리 별 아이템 개수
	public int getCateItemCount(String category) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		int count = 0;
		try {
			con = pool.getConnection();
			sql = "select count(*) from item a left outer join category b on a.categorykey = b.categorykey where itemdelete = 'N' and b.categorygroup = ? order by a.itemkey desc";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, category);
			rs = pstmt.executeQuery();
			if (rs.next()) count = rs.getInt(1);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt, rs);
		}
		return count;
	}
	
	//클래스 리스트 불러오기
	public Vector<ListBean> getClassList() {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		Vector<ListBean> vlist = new Vector<ListBean>();
		try {
			con = pool.getConnection();
			sql = "select * from class a left outer join member b on a.memberid = b.memberid where classdelete = 'Y' order by rand() limit 0, 3";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while (rs.next() ) {
				ListBean bean = new ListBean();
				bean.setKey(rs.getInt("classkey"));
				bean.setMemberid(rs.getString("memberid"));
				bean.setMembernick(rs.getString("classteachername"));
				bean.setName(rs.getString("classname"));
				bean.setPrice(rs.getInt("classprice"));
				bean.setImg1(rs.getString("classimg1"));
				bean.setMemberimg(rs.getString("classteacherimg"));
				bean.setAddress(rs.getString("address"));
				vlist.addElement(bean);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt, rs);
		}
		return vlist;
	}
	
	//클래스 리스트 불러오기
	public Vector<ListBean> getClassList(String word) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		Vector<ListBean> vlist = new Vector<ListBean>();
		try {
			con = pool.getConnection();
			sql = "select * from class a left outer join member b on a.memberid = b.memberid where classdelete = 'Y' and classname like ? order by rand()";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, "%" + word + "%");
			rs = pstmt.executeQuery();
			while (rs.next() ) {
				ListBean bean = new ListBean();
				bean.setKey(rs.getInt("classkey"));
				bean.setMemberid(rs.getString("memberid"));
				bean.setMembernick(rs.getString("classteachername"));
				bean.setName(rs.getString("classname"));
				bean.setPrice(rs.getInt("classprice"));
				bean.setImg1(rs.getString("classimg1"));
				bean.setMemberimg(rs.getString("classteacherimg"));
				bean.setAddress(rs.getString("address"));
				vlist.addElement(bean);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt, rs);
		}
		return vlist;
	}

	//모든 클래스 리스트 불러오기
	public Vector<ListBean> getAllClassList() {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		Vector<ListBean> vlist = new Vector<ListBean>();
		try {
			con = pool.getConnection();
			sql = "select * from class a left outer join member b on a.memberid = b.memberid where classdelete = 'Y' order by a.classkey desc";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while (rs.next() ) {
				ListBean bean = new ListBean();
				bean.setKey(rs.getInt("classkey"));
				bean.setMemberid(rs.getString("memberid"));
				bean.setMembernick(rs.getString("classteachername"));
				bean.setName(rs.getString("classname"));
				bean.setPrice(rs.getInt("classprice"));
				bean.setImg1(rs.getString("classimg1"));
				bean.setMemberimg(rs.getString("classteacherimg"));
				bean.setAddress(rs.getString("address"));
				vlist.addElement(bean);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt, rs);
		}
		return vlist;
	}
	
	//모든 클래스 개수
	public int getClassListCount() {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		int count = 0;
		try {
			con = pool.getConnection();
			sql = "select count(*) from class where classdelete = 'Y'";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			if (rs.next()) count = rs.getInt(1);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt, rs);
		}
		return count;
	}
	
	//카테고리 별 클래스 리스트 가져오기
	public Vector<ListBean> getCateClassList(String category) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		Vector<ListBean> vlist = new Vector<ListBean>();
		try {
			con = pool.getConnection();
			sql = "select * from class a "
					+ "left outer join member b on a.memberid = b.memberid "
					+ "left outer join category c on a.categorykey = c.categorykey "
					+ "where classdelete = 'Y' and c.categorygroup = ? order by a.classkey desc";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, category);
			rs = pstmt.executeQuery();
			while (rs.next() ) {
				ListBean bean = new ListBean();
				bean.setKey(rs.getInt("classkey"));
				bean.setMemberid(rs.getString("memberid"));
				bean.setMembernick(rs.getString("classteachername"));
				bean.setName(rs.getString("classname"));
				bean.setPrice(rs.getInt("classprice"));
				bean.setImg1(rs.getString("classimg1"));
				bean.setMemberimg(rs.getString("classteacherimg"));
				bean.setAddress(rs.getString("address"));
				vlist.addElement(bean);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt, rs);
		}
		return vlist;
	}
	
	//카테고리 별 클래스 개수
	public int getCateClassCount(String category) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		int count = 0;
		try {
			con = pool.getConnection();
			sql = "select count(*) from class a left outer join category b on a.categorykey = b.categorykey where classdelete = 'Y' and b.categorygroup = ?";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, category);
			rs = pstmt.executeQuery();
			if (rs.next()) count = rs.getInt(1);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt, rs);
		}
		return count;
	}
}