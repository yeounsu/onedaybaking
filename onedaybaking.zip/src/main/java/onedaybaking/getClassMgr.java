package onedaybaking;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;

import javax.servlet.http.HttpServletRequest;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;

public class getClassMgr {
	DBConnectionMgr pool;
	
	public getClassMgr() {
		pool = DBConnectionMgr.getInstance();
	}
	
	//클래스 신청 갯수 (개인)
	public int getapplicationclass(String id) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		int count = 0;
		try {
			con = pool.getConnection();
			sql = "select count(*) from class where memberid = ?";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, id);
			rs = pstmt.executeQuery();
			if (rs.next()) count = rs.getInt(1);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt, rs);
		}
		return count;
	}

	
	//클래스 신청 리스트
	public Vector<ClassBean> getWishItemList(String id) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		Vector<ClassBean> vlist = new Vector<ClassBean>();
		try {
			con = pool.getConnection();
			sql = "select * from class a "
					+ "left outer join class b on a.classkey = b.classkey "
					+ "left outer join member c on b.memberid = c.memberid "
					+ "where a.memberId = ? order by a.classkey desc";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, id);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				ClassBean bean = new ClassBean();
				bean.setClasskey(rs.getInt("classKey"));
				bean.setClassimg1(rs.getString("classimg1"));
				bean.setClassteacherinfo(rs.getString("classteacherinfo"));
				bean.setClassteachername(rs.getString("classteachername"));
				bean.setClassname(rs.getString("classname"));
				bean.setClassdelete(rs.getString("classdelete"));
				bean.setClassprice(rs.getInt("classprice"));
				vlist.addElement(bean);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt, rs);
		}
		return vlist;
	}
	
	 public Vector<ClassBean> getAllClassList() {
	        Connection con = null;
	        PreparedStatement pstmt = null;
	        ResultSet rs = null;
	        String sql = null;
	        Vector<ClassBean> vlist = new Vector<ClassBean>();
	        try {
	            con = pool.getConnection();
	            sql = "SELECT * FROM class";
	            pstmt = con.prepareStatement(sql);
	            rs = pstmt.executeQuery();
	            while (rs.next()) {
	                ClassBean bean = new ClassBean();
	                bean.setClasskey(rs.getInt("classKey"));
	                bean.setClassname(rs.getString("classname"));
	                bean.setClassdate(rs.getString("classdate"));
	                bean.setClassmin(rs.getInt("classmin"));
	                bean.setClassmax(rs.getInt("classmax"));
	                bean.setClassprice(rs.getInt("classprice"));
	                bean.setClasslevel(rs.getString("classlevel"));
	                bean.setClasstime(rs.getInt("classtime"));
	                bean.setAddress(rs.getString("address"));
	                bean.setAddressdetail(rs.getString("addressdetail"));
	                // 배열 형태로 저장된 데이터를 가져옵니다.
	                String[] classStatusArray = rs.getString("classstatus").split(","); // 쉼표(,)를 기준으로 배열로 분할합니다.
	                bean.setClassstatus(classStatusArray); // 분할된 배열을 설정합니다.
	                bean.setClassdelete(rs.getString("classdelete"));
	                bean.setClassteacherinfo(rs.getString("classteacherinfo"));
	                bean.setClassteacherimg(rs.getString("classteacherimg"));
	                bean.setClassimg1(rs.getString("classimg1"));
	                bean.setClassimg2(rs.getString("classimg2"));
	                bean.setClassimg3(rs.getString("classimg3"));
	                bean.setClassimg4(rs.getString("classimg4"));
	                bean.setClassimg5(rs.getString("classimg5"));
	                bean.setClasscontent(rs.getString("classcontent"));
	                bean.setRoomimg1(rs.getString("rommimg1"));
	                bean.setRoomimg2(rs.getString("rommimg2"));
	                bean.setMemberid(rs.getString("memberid"));
	                bean.setCategorykey(rs.getInt("categorykey"));
	                bean.setClassteachername(rs.getString("classteachername"));
	                vlist.addElement(bean);
	            }
	        } catch (Exception e) {
	            e.printStackTrace();
	        } finally {
	            pool.freeConnection(con, pstmt, rs);
	        }
	        return vlist;
	    }
	
	 public boolean deleteClass(int classkey) {
	        Connection con = null;
	        PreparedStatement pstmtCategory = null;
	        PreparedStatement pstmtClass = null;
	        boolean flag = false;
	        
	        try {
	            con = pool.getConnection();
	            con.setAutoCommit(false); // 자동 커밋 비활성화
	            
	            // 클래스 테이블에서 클래스의 categorykey 가져오기
	            int categoryKey = 0;
	            String sqlSelectCategoryKey = "SELECT categorykey FROM class WHERE classkey = ?";
	            pstmtCategory = con.prepareStatement(sqlSelectCategoryKey);
	            pstmtCategory.setInt(1, classkey);
	            ResultSet rs = pstmtCategory.executeQuery();
	            if (rs.next()) {
	                categoryKey = rs.getInt("categorykey");
	            }
	            rs.close();

	            // 클래스와 관련된 카테고리 테이블의 데이터 삭제
	            String sqlDeleteCategory = "DELETE FROM category WHERE categorykey = ?";
	            pstmtCategory = con.prepareStatement(sqlDeleteCategory);
	            pstmtCategory.setInt(1, categoryKey);
	            pstmtCategory.executeUpdate();

	            // 클래스 테이블에서 클래스 삭제
	            String sqlDeleteClass = "DELETE FROM class WHERE classkey = ?";
	            pstmtClass = con.prepareStatement(sqlDeleteClass);
	            pstmtClass.setInt(1, classkey);
	            if (pstmtClass.executeUpdate() == 1) {
	                flag = true;
	                con.commit(); // 커밋
	            } else {
	                con.rollback(); // 롤백
	            }
	        } catch (Exception e) {
	            e.printStackTrace();
	            if (con != null) {
	                try {
	                    con.rollback(); // 예외 발생 시 롤백
	                } catch (Exception ex) {
	                    ex.printStackTrace();
	                }
	            }
	        } finally {
	            // 자원 반환
	            if (pstmtCategory != null) {
	                try {
	                    pstmtCategory.close();
	                } catch (Exception ex) {
	                    ex.printStackTrace();
	                }
	            }
	            if (pstmtClass != null) {
	                try {
	                    pstmtClass.close();
	                } catch (Exception ex) {
	                    ex.printStackTrace();
	                }
	            }
	            if (con != null) {
	                try {
	                    con.setAutoCommit(true); // 다시 자동 커밋 활성화
	                    pool.freeConnection(con);
	                } catch (Exception ex) {
	                    ex.printStackTrace();
	                }
	            }
	        }
	        return flag;
	    }
	
}

