package onedaybaking;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Vector;

public class CartMgr {
	DBConnectionMgr pool;
	
	public CartMgr() {
		pool = DBConnectionMgr.getInstance();
	}
	
	//장바구니 목록 개수
	public int getItemCartCount(String id) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		int count = 0;
		try {
			con = pool.getConnection();
			sql = "select count(*) from itemcart where memberid = ?";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, id);
			rs = pstmt.executeQuery();
			if (rs.next()) count = rs.getInt(1);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt, rs);
		}
		return count;
	}
	
	//장바구니 목록 가져오기
	public Vector<CartBean> getItemCartList(String id) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		Vector<CartBean> vlist = new Vector<CartBean>();
		try {
			con = pool.getConnection();
			sql = "select * from itemcart a "
					+ "left outer join item b on a.itemkey = b.itemkey "
					+ "left outer join itemoption c on a.itemkey = c.itemkey "
					+ "where a.memberid = ?";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, id);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				CartBean bean = new CartBean();
				bean.setItemkey(rs.getInt("itemkey"));
				bean.setItemcount(rs.getInt("itemcartnum"));
				bean.setItemname(rs.getString("itemname"));
				bean.setItemprice(rs.getInt("itemprice"));
				String option = rs.getString("itemoption");
				String os[] = new String[option.length()];
				for (int i = 0; i < os.length; i++) {
					os[i] = option.substring(i, i + 1);
				}
				bean.setOption(os);
				vlist.addElement(bean);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt, rs);
		}
		return vlist;
	}
	
	//아이템 옵션 가져오기
	public OptionBean getItemOption(int num) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		OptionBean bean = new OptionBean();
		try {
			con = pool.getConnection();
			sql = "select * from itemoption where itemkey = ?";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, num);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				bean.setOptionkey(rs.getInt(1));
				bean.setItemoption1(rs.getString(2));
				bean.setItemoption2(rs.getString(3));
				bean.setItemoption3(rs.getString(4));
				bean.setItemoption4(rs.getString(5));
				bean.setItemoption5(rs.getString(6));
				bean.setItemoption6(rs.getString(7));
				bean.setItemoption7(rs.getString(8));
				bean.setItemoption8(rs.getString(9));
				bean.setItemoption9(rs.getString(10));
				bean.setItemoption10(rs.getString(11));
				bean.setItemsoption1(rs.getString(12));
				bean.setItemsoption2(rs.getString(13));
				bean.setItemsoption3(rs.getString(14));
				bean.setItemsoption4(rs.getString(15));
				bean.setItemsoption5(rs.getString(16));
				bean.setItemsoption6(rs.getString(17));
				bean.setItemsoption7(rs.getString(18));
				bean.setItemsoption8(rs.getString(19));
				bean.setItemsoption9(rs.getString(20));
				bean.setItemsoption10(rs.getString(21));
				bean.setItemkey(rs.getInt(22));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt, rs);
		}
		return bean;
	}
	
	//장바구니 추가
	public boolean insertCart(String id, int key, int count, String option) {
		Connection con = null;
		PreparedStatement pstmt = null;
		String sql = null;
		ResultSet rs = null;
		boolean flag = false;
		try {
			con = pool.getConnection();
			sql = "select * from itemcart where memberid = ? and itemkey = ? and itemoption = ?";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, id);
			pstmt.setInt(2, key);
			pstmt.setString(3,  option);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				int num = rs.getInt("itemcartnum");
				pool.freeConnection(con, pstmt, rs);
				sql = "update itemcart set itemcartnum = ? where memberid = ? and itemkey = ? and itemoption = ?";
				pstmt = con.prepareStatement(sql);
				pstmt.setInt(1, count + num);
				pstmt.setString(2, id);
				pstmt.setInt(3, key);
				pstmt.setString(4,  option);
				if (pstmt.executeUpdate() == 1) flag = true;
			} else {
				pool.freeConnection(con, pstmt, rs);
				sql = "insert into itemcart values (null, ?, now(), ?, ?, ?)";
				pstmt = con.prepareStatement(sql);
				pstmt.setInt(1, count);
				pstmt.setString(2, id);
				pstmt.setInt(3, key);
				pstmt.setString(4,  option);
				if (pstmt.executeUpdate() == 1) flag = true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt, rs);
		}
		return flag;
	}
	
	//장바구니 삭제
	public void deleteCart(String id, int key, String option) {
		Connection con = null;
		PreparedStatement pstmt = null;
		String sql = null;
		try {
			con = pool.getConnection();
			sql = "delete from itemcart where memberid = ? and itemkey = ? and itemoption = ?";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, id);
			pstmt.setInt(2, key);
			pstmt.setString(3, option);
			pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt);
		}
	}
}