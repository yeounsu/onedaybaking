package onedaybaking;

import java.text.SimpleDateFormat;
import java.util.Vector;

import javax.servlet.http.HttpServletRequest;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;


import java.io.File;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;

public class minjaeMgr {
	private DBConnectionMgr pool;
	private final SimpleDateFormat SDF_DATE = new SimpleDateFormat("yyyy'년'  M'월' d'일' (E)");

	public static final String SAVEFOLDER = "C:/JSP/onedaybaking/src/main/webapp/file/";

	// 업로드 파일 인코딩
	public static final String ENCODEING = "UTF-8";

	// 업로드 파일 크기
	public static final int MAXSIZE = 1024 * 1024 * 20; // 20MB

	public minjaeMgr() {
		pool = DBConnectionMgr.getInstance();
	}

	
	// 파일 다운로드
	public File downloadFile(String fileName) {
		File file = new File(SAVEFOLDER + File.separator + fileName);
		return file;
	}
	

	// 관리자 게시판 순번
	public int getMaxNumAdminBoard() {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		int maxNumAB = 0;
		try {
			con = pool.getConnection();
			sql = "select aount(*) from adminboard";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				maxNumAB = rs.getInt(1); // 현재 최대값보다 1 큰 값
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt, rs);
		}
		return maxNumAB;
	}

	
	// 관리자 게시판 리스트
	public Vector<boardBean> selectAllAdminBoards() {
		Vector<boardBean> boardList = new Vector<boardBean>();
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		try {
			con = pool.getConnection();
			sql = "SELECT * FROM adminboard ORDER BY num DESC";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				boardBean board = new boardBean();
				board.setNum(rs.getInt("num"));
				board.setEname(rs.getString("ename"));
				board.setKname(rs.getString("kname"));
				board.setUsevalue(rs.getString("usevalue"));
				board.setListvalue(rs.getString("listvalue"));
				board.setReadvalue(rs.getString("readvalue"));
				board.setWritevalue(rs.getString("writevalue"));
				boardList.add(board);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt, rs);
		}
		return boardList;
	}
	

	// 관리자 게시판 만들기
	public void insertboard(boardBean bean) {
		Connection con = null;
		PreparedStatement pstmt = null;
		String sql = null;
		try {
			con = pool.getConnection();
			sql = "insert adminboard values(?,?,?,?,?,?,?)";
			pstmt = con.prepareStatement(sql);
			int listNum = getMaxNumAdminBoard();
			pstmt.setInt(1, listNum);
			pstmt.setString(2, bean.getEname());
			pstmt.setString(3, bean.getKname());
			pstmt.setString(4, "0");
			pstmt.setString(5, bean.getListvalue());
			pstmt.setString(6, bean.getReadvalue());
			pstmt.setString(7, bean.getWritevalue());
			pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt);
		}
	}
	

	// 관리자 게시판 지우기
	public void deleteboard(boardBean bean) {
		Connection con = null;
		PreparedStatement pstmt = null;
		String sql = null;
		try {
			con = pool.getConnection();
			sql = "delete from adminboard where num = ?";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, bean.getNum());
			pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt);
		}
	}
	

	// 유저 게시글 순번
	public int getMaxNumUserBoard() {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		int maxNumUB = 0;
		try {
			con = pool.getConnection();
			sql = "select count(*) from announce";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				maxNumUB = rs.getInt(1); // 현재 최대값보다 1 큰 값
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt, rs);
		}
		return maxNumUB;
	}
	

	// 유저 게시글 작성
	public void writeboard(HttpServletRequest req, String writer) {
		Connection con = null;
		PreparedStatement pstmt = null;
		String sql = null;
		try {
			File dir = new File(SAVEFOLDER);
			if (!dir.exists()) {
				dir.mkdirs();
			}
			MultipartRequest multi = new MultipartRequest(req, SAVEFOLDER, MAXSIZE, ENCODEING,
					new DefaultFileRenamePolicy());
			String filename = null;
			int filesize = 0;
			if (multi.getFilesystemName("filename") != null) {
				filename = multi.getFilesystemName("filename");
				File file = multi.getFile("filename");
				filesize = (int) file.length();
			}
			con = pool.getConnection();
			sql = "insert into announce (announceSubject, announceContent, announceWriter, announceDay, announceView, filename, filesize) values (?,?,?,now(),?,?,?)";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, multi.getParameter("title"));
			pstmt.setString(2, multi.getParameter("content"));
			pstmt.setString(3, writer);
			pstmt.setInt(4, 0); // 조회수 초기값 0으로 설정
			pstmt.setString(5, filename);
			pstmt.setInt(6, filesize);
			pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt);
		}
	}
	

	// 유저 게시글 리스트
	public Vector<announceBean> selectAllUserBoards() {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		Vector<announceBean> announceList = new Vector<announceBean>();
		try {
			con = pool.getConnection();
			sql = "SELECT * FROM announce ORDER BY announceNum DESC";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				announceBean announce = new announceBean();
				announce.setAnnounceNum(rs.getInt("announceNum"));
				announce.setAnnounceSubject(rs.getString("announceSubject"));
				announce.setAnnounceContent(rs.getString("announceContent"));
				announce.setAnnounceWriter(rs.getString("announceWriter"));
				announce.setAnnounceDay(rs.getString("announceDay"));
				announce.setAnnounceView(rs.getInt("announceView"));
				announce.setAnnounceFile(rs.getString("filename"));
				announceList.add(announce);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt, rs);
		}
		return announceList;
	}
	
	
	// 게시물 상세
	public announceBean getAnnounce(int num) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		announceBean bean = new announceBean();
		try {
			con = pool.getConnection();
			sql = "select * from announce where announceNum = ?";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, num);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				bean.setAnnounceNum(rs.getInt("announceNum"));
				bean.setAnnounceSubject(rs.getString("announceSubject"));
				bean.setAnnounceContent(rs.getString("announceContent"));
				bean.setAnnounceWriter(rs.getString("announceWriter"));
				bean.setAnnounceDay(rs.getString("announceDay"));
				bean.setAnnounceView(rs.getInt("announceView"));
				bean.setAnnounceFile(rs.getString("filename"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt, rs);
		}
		return bean;
	}
	
	
	// 게시글 조회수
	public void upCount(int announceNum) {
		Connection con = null;
		PreparedStatement pstmt = null;
		String sql = null;
		int upCount = 0;
		try {
			con = pool.getConnection();
			sql = "update announce set announceView = announceView+1 where announceNum=?";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, announceNum);
			pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt);
		}
	}
	

	// 게시글 삭제
	public void deleteAnnounce(int announceNum) {
	    Connection con = null;
	    PreparedStatement pstmt = null;
	    try {
	        con = pool.getConnection();
	        String sql = "DELETE FROM announce WHERE announceNum = ?";
	        pstmt = con.prepareStatement(sql);
	        pstmt.setInt(1, announceNum);
	        pstmt.executeUpdate();
	    } catch (Exception e) {
	        e.printStackTrace();
	    } finally {
	        pool.freeConnection(con, pstmt);
	    }
	}

	
	// 내 클래스 관리
	public MyclassBean myClassCare(String memberId, String classorderdate) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		MyclassBean bean = new MyclassBean();
		try {
			con = pool.getConnection();
			sql = "select c.classkey, c.classname, m.memberName, m.memberPhone, co.classtotal\r\n"
					+ "from onedaybaking.classorder co\r\n"
			        + "left outer join member m\r\n"    
			        + "on m.memberId = co.memberId\r\n"
			        + "left outer join class c\r\n"
			        + "on c.classkey = co.classkey\r\n"
			        + "where c.memberId=? and co.classorderdate=?";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, memberId);
			pstmt.setString(2, classorderdate);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				bean.setClassKey(rs.getInt("classKey"));
				bean.setClassname(rs.getString("classname"));
				bean.setMemberName(rs.getString("memberName"));
				bean.setMemberPhone(rs.getString("memberPhone"));
				bean.setClasstotal(rs.getInt("classtotal"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt, rs);
		}
		return bean;
	}
	
	
	
}
