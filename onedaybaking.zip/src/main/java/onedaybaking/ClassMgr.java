package onedaybaking;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Vector;

public class ClassMgr {
	DBConnectionMgr pool;
	
	public ClassMgr() {
		pool = DBConnectionMgr.getInstance();
	}
	
	//특정 클래스 정보 가져오기
	public ClassBean getClass(int key) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		ClassBean bean = new ClassBean();
		try {
			con = pool.getConnection();
			sql = "select * from class where classkey = ?";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, key);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				bean.setClasskey(rs.getInt(1));
				bean.setClassname(rs.getString(2));
				bean.setClassmin(rs.getInt(4));
				bean.setClassmax(rs.getInt(5));
				bean.setClassprice(rs.getInt(6));
				bean.setClasslevel(rs.getString(7));
				bean.setClasstime(rs.getInt(8));
				bean.setAddress(rs.getString(9));
				bean.setAddressdetail(rs.getString(10));
				String option = rs.getString(12);
				String os[] = new String[option.length()];
				for (int i = 0; i < os.length; i++) {
					os[i] = option.substring(i, i + 1);
				}
				bean.setClassstatus(os);
				bean.setClassdelete(rs.getString(13));
				bean.setClassteacherinfo(rs.getString(14));
				bean.setClassteacherimg(rs.getString(15));
				bean.setClassimg1(rs.getString(16));
				bean.setClassimg2(rs.getString(17));
				bean.setClassimg3(rs.getString(18));
				bean.setClassimg4(rs.getString(19));
				bean.setClassimg5(rs.getString(20));
				bean.setClasscontent(rs.getString(21));
				bean.setRoomimg1(rs.getString(22));
				bean.setRoomimg2(rs.getString(23));
				bean.setMemberid(rs.getString(24));
				MemberMgr mgr = new MemberMgr();
				MemberBean mbean = mgr.memberList(rs.getString(24));
				bean.setMembername(mbean.getMemberNick());
				bean.setMemberimg(mbean.getMemberInfoImg());
				bean.setCategorykey(rs.getInt(25));
				bean.setClassteachername(rs.getString(26));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt, rs);
		}
		return bean;
	}
	
	//클래스 전체 개수
	public int getTotalClassCount(String keyField, String keyWord, String sdate, String edate) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		int totalCount = 0;
		try {
			con = pool.getConnection();
			if (keyWord.trim().equals("") || keyWord == null) {
				if (sdate.trim().equals("") || sdate == null) {
					sql = "select count(*) from class";
					pstmt = con.prepareStatement(sql);
				} else {
					sql = "select count(*) from class where classdate between ? and ?";
					pstmt = con.prepareStatement(sql);
					pstmt.setString(1, sdate);
					pstmt.setString(2, edate);
				}
			} else if (keyWord != null && sdate != null) {
				if (sdate.trim().equals("") || sdate == null) {
					if (keyField.equals("memberid")) {
						sql = "select count(*) from class where " + keyField + " = ?";
						pstmt = con.prepareStatement(sql);
						pstmt.setString(1, keyWord);
					} else {
						sql = "select count(*) from class a left outer join member b on a.memberid = b.memberid where " + keyField + " like ?";
						pstmt = con.prepareStatement(sql);
						pstmt.setString(1, "%" + keyWord + "%");
					}
				} else {
					sql = "select count(*) from class a left outer join member b on a.memberid = b.memberid "
							+ "where " + keyField + " = ?  and classdate between ? and ?";
					pstmt = con.prepareStatement(sql);
					pstmt.setString(1, keyWord);
					pstmt.setString(2, sdate);
					pstmt.setString(3, edate);
				}
			}
			rs = pstmt.executeQuery();
			if (rs.next()) totalCount = rs.getInt(1);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt, rs);
		}
		return totalCount;
	}
	
	//클래스 찜 여부
	public boolean isWishClass(String id, int classkey) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		boolean flag = false;
		try {
			con = pool.getConnection();
			sql = "select * from wish where memberid = ? and classkey = ?";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, id);
			pstmt.setInt(2, classkey);
			rs = pstmt.executeQuery();
			if (rs.next()) flag = true;
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt, rs);
		}
		return flag;
	}
	
	//관리자
	//클래스 목록 가져오기 (
	public Vector<ClassBean> getAllClass(String keyField, String keyWord, int start, int cnt, String sdate, String edate) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		Vector<ClassBean> vlist = new Vector<ClassBean>();
		try {
			con = pool.getConnection();
			if (keyWord.trim().equals("") || keyWord == null) {
				if (sdate.trim().equals("") || sdate == null) {
					sql = "select classkey, b.membername, classname, classprice, classtime, a.memberid, classdate, classdelete from class a left outer join member b on a.memberid = b.memberid order by classkey desc limit ?, ?";
					pstmt = con.prepareStatement(sql);
					pstmt.setInt(1, start);
					pstmt.setInt(2, cnt);
				} else {
					sql = "select classkey, b.membername, classname, classprice, classtime, a.memberid, classdate, classdelete from class a left outer join member b on a.memberid = b.memberid where classdate between ? and ? order by classkey desc limit ?, ?";
					pstmt = con.prepareStatement(sql);
					pstmt.setString(1, sdate);
					pstmt.setString(2, edate);
					pstmt.setInt(3, start);
					pstmt.setInt(4, cnt);
				}
			} else if (keyWord != null && sdate != null) {
				if (sdate.trim().equals("") || sdate == null) {
					if (keyField.equals("memberid")) {
						sql = "select classkey, b.membername, classname, classprice, classtime, a.memberid, classdate, classdelete from class a left outer join member b on a.memberid = b.memberid where " + keyField + " = ? order by classkey desc limit ?, ?";
						pstmt = con.prepareStatement(sql);
						pstmt.setString(1, keyWord);
						pstmt.setInt(2, start);
						pstmt.setInt(3, cnt);
					} else {
						sql = "select classkey, b.membername, classname, classprice, classtime, a.memberid, classdate, classdelete from class a left outer join member b on a.memberid = b.memberid where " + keyField + " like ? order by classkey desc limit ?, ?";
						pstmt = con.prepareStatement(sql);
						pstmt.setString(1, "%" + keyWord + "%");
						pstmt.setInt(2, start);
						pstmt.setInt(3, cnt);
					}
				} else {
					sql = "select classkey, b.membername, classname, classprice, classtime, a.memberid, classdate, classdelete from class a left outer join member b on a.memberid = b.memberid where " + keyField + " = ?  and classdate between ? and ? order by classkey desc limit ?, ?";
					pstmt = con.prepareStatement(sql);
					pstmt.setString(1, keyWord);
					pstmt.setString(2, sdate);
					pstmt.setString(3, edate);
					pstmt.setInt(4, start);
					pstmt.setInt(5, cnt);
				}
			}
			rs = pstmt.executeQuery();
			while (rs.next()) {
				ClassBean bean = new ClassBean();
				bean.setClasskey(rs.getInt("classkey"));
				bean.setMembername(rs.getString("membername"));
				bean.setClassname(rs.getString("classname"));
				bean.setClassprice(rs.getInt("classprice"));
				bean.setClasstime(rs.getInt("classtime"));
				bean.setMemberid(rs.getString("memberid"));
				bean.setClassdate(rs.getString("classdate"));
				bean.setClassdelete(rs.getString("classdelete"));
				vlist.addElement(bean);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt, rs);
		}
		return vlist;
	}
	
	public void delClassOrder(String id, int totalkey, int classkey) {
		Connection con = null;
		PreparedStatement pstmt = null;
		String sql = null;
		try {
			con = pool.getConnection();
			sql = "delete from totalorder where totalorderkey = ? and memberid = ?";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, totalkey);
			pstmt.setString(2, id);
			pstmt.executeUpdate();

			pool.freeConnection(con, pstmt);
			con = pool.getConnection();
			sql = "delete from classorderdetail where classorderkey = ?";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, classkey);
			pstmt.executeUpdate();

			pool.freeConnection(con, pstmt);
			con = pool.getConnection();
			sql = "delete from classorder where classorderkey = ?";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, classkey);
			pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt);
		}
		
	}
}