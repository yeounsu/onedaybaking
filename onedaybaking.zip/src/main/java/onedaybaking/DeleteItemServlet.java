package onedaybaking;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/DeleteItemServlet")
public class DeleteItemServlet extends HttpServlet {
    private getItemMgr getItemMgr;
    
    @Override
    public void init() throws ServletException {
        super.init();
        getItemMgr = new getItemMgr();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // 요청 파라미터 읽기
        String action = request.getParameter("action");
        String itemKeyParameter = request.getParameter("itemkey");
        if (itemKeyParameter != null && !itemKeyParameter.isEmpty()) {
            int itemkey = Integer.parseInt(itemKeyParameter);
            
            // 클래스 삭제 작업 수행
            boolean deleteResult = getItemMgr.deleteItem(itemkey);
            
            // 응답 작성
            response.setContentType("text/plain");
            if (deleteResult) {
                response.getWriter().write("Item deleted successfully.");
            } else {
                response.getWriter().write("Failed to delete item.");
            }
        } else {
            System.out.println("itemKeyParameter is null or empty.");
        }
        
    }
}
