package onedaybaking;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Vector;

public class MemberMgr2 {
	DBConnectionMgr pool;
	
	public MemberMgr2() {
		pool = DBConnectionMgr.getInstance();
	}
	
	//클래스 전체 개수
	public int getTotalMemberCount(String keyField, String keyWord, String sdate, String edate) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		int totalCount = 0;
		if (!sdate.trim().equals("")) {
			sdate += " 00:00:00";
			edate += " 23:59:59";
		}
		try {
			con = pool.getConnection();
			if (keyWord.trim().equals("") || keyWord == null) {
				if (sdate.trim().equals("") || sdate == null) {
					sql = "select count(*) from member";
					pstmt = con.prepareStatement(sql);
				} else {
					sql = "select count(*) from member where memberdate between ? and ?";
					pstmt = con.prepareStatement(sql);
					pstmt.setString(1, sdate);
					pstmt.setString(2, edate);
				}
			} else if (keyWord != null && sdate != null) {
				if (sdate.trim().equals("") || sdate == null) {
					if (keyField.equals("memberid")) {
						sql = "select count(*) from member where " + keyField + " = ?";
						pstmt = con.prepareStatement(sql);
						pstmt.setString(1, keyWord);
					} else {
						sql = "select count(*) from member where " + keyField + " like ?";
						pstmt = con.prepareStatement(sql);
						pstmt.setString(1, "%" + keyWord + "%");
					}
				} else {
					sql = "select count(*) from member where " + keyField + " = ?  and memberdate between ? and ?";
					pstmt = con.prepareStatement(sql);
					pstmt.setString(1, keyWord);
					pstmt.setString(2, sdate);
					pstmt.setString(3, edate);
				}
			}
			rs = pstmt.executeQuery();
			if (rs.next()) totalCount = rs.getInt(1);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt, rs);
		}
		return totalCount;
	}
	
	//주문 상품 수
	public int getOrderItem(String id) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		int count = 0;
		try {
			con = pool.getConnection();
			sql = "select count(*) from itemorder where memberid = ?";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, id);
			rs = pstmt.executeQuery();
			if (rs.next()) count = rs.getInt(1);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt, rs);
		}
		return count;
	}
	
	//예약 클래스 수
	public int getResvClass(String id) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		int count = 0;
		try {
			con = pool.getConnection();
			sql = "select count(*) from classorder where memberid = ?";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, id);
			rs = pstmt.executeQuery();
			if (rs.next()) count = rs.getInt(1);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt, rs);
		}
		return count;
	}
	
	//관리자
	//회원 목록 가져오기 (
	public Vector<MemberBean> getAllMember(String keyField, String keyWord, int start, int cnt, String sdate, String edate) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		Vector<MemberBean> vlist = new Vector<MemberBean>();
		if (!sdate.trim().equals("")) {
			sdate += " 00:00:00";
			edate += " 23:59:59";
		}
		System.out.println(sdate + " " + edate);
		try {
			con = pool.getConnection();
			if (keyWord.trim().equals("") || keyWord == null) {
				if (sdate.trim().equals("") || sdate == null) {
					sql = "select * from member order by memberdate desc limit ?, ?";
					pstmt = con.prepareStatement(sql);
					pstmt.setInt(1, start);
					pstmt.setInt(2, cnt);
				} else {
					sql = "select * from member where memberdate between ? and ? order by memberdate desc limit ?, ?";
					pstmt = con.prepareStatement(sql);
					pstmt.setString(1, sdate);
					pstmt.setString(2, edate);
					pstmt.setInt(3, start);
					pstmt.setInt(4, cnt);
				}
			} else if (keyWord != null && sdate != null) {
				if (sdate.trim().equals("") || sdate == null) {
					if (keyField.equals("memberid")) {
						sql = "select * from member where " + keyField + " = ? order by memberdate desc limit ?, ?";
						pstmt = con.prepareStatement(sql);
						pstmt.setString(1, keyWord);
						pstmt.setInt(2, start);
						pstmt.setInt(3, cnt);
					} else {
						sql = "select * from member where " + keyField + " like ? order by memberdate desc limit ?, ?";
						pstmt = con.prepareStatement(sql);
						pstmt.setString(1, "%" + keyWord + "%");
						pstmt.setInt(2, start);
						pstmt.setInt(3, cnt);
					}
				} else {
					sql = "select * from member where " + keyField + " = ?  and memberdate between ? and ? order by memberdate desc limit ?, ?";
					pstmt = con.prepareStatement(sql);
					pstmt.setString(1, keyWord);
					pstmt.setString(2, sdate);
					pstmt.setString(3, edate);
					pstmt.setInt(4, start);
					pstmt.setInt(5, cnt);
				}
			}
			rs = pstmt.executeQuery();
			while (rs.next()) {
				MemberBean bean = new MemberBean();
				bean.setMemberId(rs.getString("memberid"));
				bean.setMemberName(rs.getString("membername"));
				bean.setMemberBirth(rs.getString("memberbirth"));
				bean.setMemberSex(rs.getString("membersex"));
				bean.setMemberPhone(rs.getString("memberphone"));
				bean.setMemberdate(rs.getString("memberdate"));
				bean.setSignout(rs.getString("signout"));
				vlist.addElement(bean);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt, rs);
		}
		return vlist;
	}
	
	//회원 전체 가져오기
	public Vector<String> getAllMembers() {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		Vector<String> vlist = new Vector<>();
		try {
			con = pool.getConnection();
			sql = "select memberId from member where signout = 'N'";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				vlist.addElement(rs.getString(1));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt, rs);
		}
		return vlist;
	}
}