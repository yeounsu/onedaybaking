package onedaybaking;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Vector;

public class OrderMgr {
	DBConnectionMgr pool;
	
	public OrderMgr() {
		pool = DBConnectionMgr.getInstance();
	}
	
	//상품 주문 개수
	public int getItemOrderCount(String keyField, String keyWord, String sdate, String edate) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		int count = 0;
		if (!sdate.trim().equals("")) {
			sdate += " 00:00:00";
			edate += " 23:59:59";
		}
		try {
			con = pool.getConnection();
			if (keyWord.trim().equals("") || keyWord == null) {
				if (sdate.trim().equals("") || sdate == null) {
					sql = "select count(*) from totalorder where classorderkey is null and itemorderkey is not null";
					pstmt = con.prepareStatement(sql);
				} else {
					sql = "select count(*) from totalorder where orderdate between ? and ? and classorderkey is null and itemorderkey is not null";
					pstmt = con.prepareStatement(sql);
					pstmt.setString(1, sdate);
					pstmt.setString(2, edate);
				}
			} else if (keyWord != null && sdate != null) {
				if (sdate.trim().equals("") || sdate == null) {
					if (keyField.equals("memberid")) {
						sql = "select count(*) from totalorder where " + keyField + " = ? and classorderkey is null and itemorderkey is not null";
						pstmt = con.prepareStatement(sql);
						pstmt.setString(1, keyWord);
					} else {
						sql = "select count(*) from totalorder a left outer join member b on a.memberid = b.memberid where " + keyField + " like ? and classorderkey is null and itemorderkey is not null";
						pstmt = con.prepareStatement(sql);
						pstmt.setString(1, "%" + keyWord + "%");
					}
				} else {
					sql = "select count(*) from totalorder a left outer join member b on a.memberid = b.memberid where " + keyField + " = ?  and orderdate between ? and ? and classorderkey is null and itemorderkey is not null";
					pstmt = con.prepareStatement(sql);
					pstmt.setString(1, keyWord);
					pstmt.setString(2, sdate);
					pstmt.setString(3, edate);
				}
			}
			rs = pstmt.executeQuery();
			if (rs.next()) count = rs.getInt(1);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt, rs);
		}
		return count;
	}
	
	//클래스 예약 개수
	public int getClassResvCount(String keyField, String keyWord, String sdate, String edate) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		int count = 0;
		if (!sdate.trim().equals("")) {
			sdate += " 00:00:00";
			edate += " 23:59:59";
		}
		try {
			con = pool.getConnection();
			if (keyWord.trim().equals("") || keyWord == null) {
				if (sdate.trim().equals("") || sdate == null) {
					sql = "select count(*) from totalorder where classorderkey is not null and itemorderkey is null";
					pstmt = con.prepareStatement(sql);
				} else {
					sql = "select count(*) from totalorder where orderdate between ? and ? and classorderkey is not null and itemorderkey is null";
					pstmt = con.prepareStatement(sql);
					pstmt.setString(1, sdate);
					pstmt.setString(2, edate);
				}
			} else if (keyWord != null && sdate != null) {
				if (sdate.trim().equals("") || sdate == null) {
					if (keyField.equals("memberid")) {
						sql = "select count(*) from totalorder where " + keyField + " = ? and classorderkey is not null and itemorderkey is null";
						pstmt = con.prepareStatement(sql);
						pstmt.setString(1, keyWord);
					} else {
						sql = "select count(*) from totalorder a left outer join member b on a.memberid = b.memberid where " + keyField + " like ? and classorderkey is not null and itemorderkey is null";
						pstmt = con.prepareStatement(sql);
						pstmt.setString(1, "%" + keyWord + "%");
					}
				} else {
					sql = "select count(*) from totalorder a left outer join member b on a.memberid = b.memberid where " + keyField + " = ?  and orderdate between ? and ? and classorderkey is not null and itemorderkey is null";
					pstmt = con.prepareStatement(sql);
					pstmt.setString(1, keyWord);
					pstmt.setString(2, sdate);
					pstmt.setString(3, edate);
				}
			}
			rs = pstmt.executeQuery();
			if (rs.next()) count = rs.getInt(1);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt, rs);
		}
		return count;
	}
	
	//상품 주문 목록
	public Vector<TotalorderBean> getItemOrderList(String keyField, String keyWord, int start, int cnt, String sdate, String edate, String id) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		Vector<TotalorderBean> vlist = new Vector<TotalorderBean>();
		if (!sdate.trim().equals("")) {
			sdate += " 00:00:00";
			edate += " 23:59:59";
		}
		try {
			con = pool.getConnection();
			if (keyWord.trim().equals("") || keyWord == null) {
				if (sdate.trim().equals("") || sdate == null) {
					sql = "select * from totalorder a "
							+ "left outer join itemorder b on a.itemorderkey = b.itemorderkey "
							+ "left outer join itemorderdetail c on a.itemorderkey = c.orderkey "
							+ "left outer join `member` d on a.memberid = d.memberid "
							+ "where a.classorderkey is null and a.itemorderkey is not null order by totalorderkey desc limit ?, ?";
					pstmt = con.prepareStatement(sql);
					pstmt.setInt(1, start);
					pstmt.setInt(2, cnt);
				} else {
					sql = "select * from totalorder a "
							+ "left outer join itemorder b on a.itemorderkey = b.itemorderkey "
							+ "left outer join itemorderdetail c on a.itemorderkey = c.orderkey "
							+ "left outer join `member` d on a.memberid = d.memberid "
							+ "where a.orderdate between ? and ? and a.classorderkey is null and a.itemorderkey is not null order by totalorderkey desc limit ?, ?";
					pstmt = con.prepareStatement(sql);
					pstmt.setString(1, sdate);
					pstmt.setString(2, edate);
					pstmt.setInt(3, start);
					pstmt.setInt(4, cnt);
				}
			} else if (keyWord != null && sdate != null) {
				if (sdate.trim().equals("") || sdate == null) {
					if (keyField.equals("memberid")) {
						sql = "select * from totalorder a "
								+ "left outer join itemorder b on a.itemorderkey = b.itemorderkey "
								+ "left outer join itemorderdetail c on a.itemorderkey = c.orderkey "
								+ "left outer join `member` d on a.memberid = d.memberid "
								+ "where a." + keyField + " = ? and a.classorderkey is null and a.itemorderkey is not null order by totalorderkey desc limit ?, ?";
						pstmt = con.prepareStatement(sql);
						pstmt.setString(1, keyWord);
						pstmt.setInt(2, start);
						pstmt.setInt(3, cnt);
					} else {
						sql = "select * from totalorder a "
								+ "left outer join itemorder b on a.itemorderkey = b.itemorderkey "
								+ "left outer join itemorderdetail c on a.itemorderkey = c.orderkey "
								+ "left outer join `member` d on a.memberid = d.memberid "
								+ "where " + keyField + " like ? and a.classorderkey is null and a.itemorderkey is not null order by totalorderkey desc limit ?, ?";
						pstmt = con.prepareStatement(sql);
						pstmt.setString(1, "%" + keyWord + "%");
						pstmt.setInt(2, start);
						pstmt.setInt(3, cnt);
					}
				} else {
					sql = "select * from totalorder a "
							+ "left outer join itemorder b on a.itemorderkey = b.itemorderkey "
							+ "left outer join itemorderdetail c on a.itemorderkey = c.orderkey "
							+ "left outer join `member` d on a.memberid = d.memberid "
							+ "where " + keyField + " = ?  and a.orderdate between ? and ? and a.classorderkey is null and a.itemorderkey is not null "
							+ "order by totalorderkey desc limit ?, ?";
					pstmt = con.prepareStatement(sql);
					pstmt.setString(1, keyWord);
					pstmt.setString(2, sdate);
					pstmt.setString(3, edate);
					pstmt.setInt(4, start);
					pstmt.setInt(5, cnt);
				}
			}
			rs = pstmt.executeQuery();
			while (rs.next()) {
				TotalorderBean bean = new TotalorderBean();
				bean.setTotalorderkey(rs.getInt("totalorderkey"));
				bean.setMembername(rs.getString("membername"));
				bean.setOrdername(rs.getString("ordername"));
				bean.setPhone(rs.getString("orderphone"));
				bean.setOrdercard(rs.getString("ordercard"));
				bean.setTotalprice(rs.getInt("totalprice"));
				bean.setOrderdate(rs.getString("orderdate"));
				bean.setOrderstate(rs.getString("itemorderstate"));
				bean.setMemberid(rs.getString("memberid"));
				vlist.addElement(bean);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt, rs);
		}
		return vlist;
	}
	
	//상품 주문
	public boolean insertOrderItem(String id, String zip, String addr, String addrdetail, String req, String name, String phone, int coupon, int total, String card, String uid) {
		Connection con = null;
		PreparedStatement pstmt = null;
		String sql = null;
		boolean flag = false;
		ResultSet rs = null;
		int orderkey = 0;
		try {
			con = pool.getConnection();
			sql = "insert into itemorder values (null, null, ?, ?, ?, ?, now(), ?, ?, ?)";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, zip);
			pstmt.setString(2, addr);
			pstmt.setString(3, addrdetail);
			pstmt.setString(4, req);
			pstmt.setString(5, id);
			pstmt.setString(6, name);
			pstmt.setString(7, phone);
			if (pstmt.executeUpdate() == 1) {
				pool.freeConnection(con, pstmt);
				con = pool.getConnection();
				sql = "select itemorderkey from itemorder order by itemorderkey desc";
				pstmt = con.prepareStatement(sql);
				rs = pstmt.executeQuery();
				if (rs.next()) {
					orderkey = rs.getInt(1);
					pool.freeConnection(con, pstmt, rs);
					con = pool.getConnection();
					sql = "insert into totalorder values (null, ?, ?, now(), ?, null, ?, ?, ?)";
					pstmt = con.prepareStatement(sql);
					pstmt.setInt(1, total);
					pstmt.setString(2, card);
					pstmt.setString(3, id);
					pstmt.setInt(4, orderkey);
					pstmt.setInt(5, coupon);
					pstmt.setString(6, uid);
					if (pstmt.executeUpdate() == 1) {
						CartMgr cmgr = new CartMgr();
						Vector<CartBean> vlist = cmgr.getItemCartList(id);
						for (int i = 0; i < vlist.size(); i++) {
							CartBean cbean = vlist.get(i);
							pool.freeConnection(con, pstmt, rs);
							con = pool.getConnection();
							sql = "insert into itemorderdetail values (null, ?, ?, '결제완료', ?, ?, ?)";
							pstmt = con.prepareStatement(sql);
							pstmt.setInt(1, cbean.getItemcount());
							pstmt.setInt(2, cbean.getItemprice());
							pstmt.setInt(3, orderkey);
							pstmt.setInt(4, cbean.getItemkey());
							String option = "";
							for (int j = 0; j < 20; j++) {
								option += cbean.getOption()[j]; 
							}
							pstmt.setString(5, option);
							pstmt.executeUpdate();
						}
						
						pool.freeConnection(con, pstmt);
						con = pool.getConnection();
						sql = "delete from itemcart where memberid = ?";
						pstmt = con.prepareStatement(sql);
						pstmt.setString(1, id);
						pstmt.executeUpdate();

						pool.freeConnection(con, pstmt);
						con = pool.getConnection();
						sql = "update coupon set couponstatus = 'Y' where memberid = ? and couponkey = ?";
						pstmt = con.prepareStatement(sql);
						pstmt.setString(1, id);
						pstmt.setInt(2, coupon);
						pstmt.executeUpdate();
						
						flag = true;
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt, rs);
		}
		return flag;
	}
	
	//클래스 예약
	public boolean insertOrderClass(String id, int classprice, int classcount, int key, int totalprice, String card, int coupon, String uid, String date) {
		Connection con = null;
		PreparedStatement pstmt = null;
		String sql = null;
		ResultSet rs = null;
		boolean flag = false;
		try {
			con = pool.getConnection();
			sql = "insert into classorder values (null, ?, ?, ?, ?, ?)";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, date);
			pstmt.setInt(2, classcount);
			pstmt.setInt(3, classprice);
			pstmt.setInt(4, key);
			pstmt.setString(5, id);
			if (pstmt.executeUpdate() == 1) {
				pool.freeConnection(con, pstmt);
				con = pool.getConnection();
				sql = "select classorderkey from classorder order by classorderkey desc";
				pstmt = con.prepareStatement(sql);
				rs = pstmt.executeQuery();
				if (rs.next()) {
					int orderkey = rs.getInt(1);
					pool.freeConnection(con, pstmt, rs);
					con = pool.getConnection();
					sql = "insert into classorderdetail values (null, 'N', ?, ?)";
					pstmt = con.prepareStatement(sql);
					pstmt.setInt(1, orderkey);
					pstmt.setString(2, id);
					if (pstmt.executeUpdate() == 1) {
						pool.freeConnection(con, pstmt, rs);
						con = pool.getConnection();
						sql = "insert into totalorder values (null, ?, ?, now(), ?, ?, null, ?, ?)";
						pstmt = con.prepareStatement(sql);
						pstmt.setInt(1, totalprice);
						pstmt.setString(2, card);
						pstmt.setString(3, id);
						pstmt.setInt(4, orderkey);
						pstmt.setInt(5, coupon);
						pstmt.setString(6, uid);
						if (pstmt.executeUpdate() == 1) flag = true;
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt, rs);
		}
		return flag;
	}
	
	//배송 상태별 상품 주문 개수
	public int getItemOrderState(String state) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		int count = 0;
		try {
			con = pool.getConnection();
			sql = "select count(*) from itemorderdetail where itemorderstate = ? group by orderkey";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, state);
			rs = pstmt.executeQuery();
			if (rs.next()) count = rs.getInt(1);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt, rs);
		}
		return count;
	}
	
	//관리자
	//상품 주문 개수
	public int getAllItems() {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		int count = 0;
		try {
			con = pool.getConnection();
			sql = "select count(*) from totalorder where classorderkey is null and itemorderkey is not null";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			if (rs.next()) count = rs.getInt(1);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt, rs);
		}
		return count;
	}
	
	//상품 주문 총 금액
	public int getAllItemPrice() {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		int count = 0;
		try {
			con = pool.getConnection();
			sql = "select totalprice from totalorder where classorderkey is null and itemorderkey is not null";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while (rs.next())
				count += rs.getInt(1);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt, rs);
		}
		return count;
	}
	
	//최근 주문 상품
	public Vector<ItemOrderBean> getRecentOrder() {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		Vector<ItemOrderBean> vlist = new Vector<ItemOrderBean>();
		try {
			con = pool.getConnection();
			sql = "select * from itemorder a "
					+ "left outer join member b on a.memberid = b.memberid "
					+ "left outer join totalorder c on a.itemorderkey = c.itemorderkey "
					+ "order by a.itemorderkey desc limit 0, 3";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				ItemOrderBean bean = new ItemOrderBean();
				bean.setItemOrderKey(rs.getInt(1));
				bean.setMembername(rs.getString("membername"));
				bean.setOrderName(rs.getString("ordername"));
				bean.setOrderPhone(rs.getString("orderphone"));
				bean.setTotalprice(rs.getInt("totalprice"));
				bean.setCard(rs.getString("ordercard"));
				bean.setItemOrderDate(rs.getString("itemorderdate"));
				bean.setOrderMemberId(rs.getString("memberid"));
				vlist.addElement(bean);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt, rs);
		}
		return vlist;
	}
	
	//최근 등록 상품
	public Vector<ItemBean> getRecentItem() {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		Vector<ItemBean> vlist = new Vector<ItemBean>();
		try {
			con = pool.getConnection();
			sql = "select * from item a left outer join member b on a.memberid = b.memberid order by itemkey desc limit 0, 3";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				ItemBean bean = new ItemBean();
				bean.setItemkey(rs.getInt(1));
				bean.setMemberid(rs.getString("memberid"));
				bean.setItemname(rs.getString("itemname"));
				bean.setItemprice(rs.getInt("itemprice"));
				bean.setMembername(rs.getString("membername"));
				bean.setItemdate(rs.getString("itemdate"));
				bean.setItemdelete(rs.getString("itemdelete"));
				vlist.addElement(bean);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt, rs);
		}
		return vlist;
	}
	
	//최근 등록 클래스
	public Vector<ClassBean> getRecentClass() {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		Vector<ClassBean> vlist = new Vector<ClassBean>();
		try {
			con = pool.getConnection();
			sql = "select * from class a left outer join member b on a.memberid = b.memberid order by classkey desc limit 0, 3";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				ClassBean bean = new ClassBean();
				bean.setClasskey(rs.getInt(1));
				bean.setMembername(rs.getString("membername"));
				bean.setClassname(rs.getString("classname"));
				bean.setClassprice(rs.getInt("classprice"));
				bean.setClasstime(rs.getInt("classtime"));
				bean.setClassdate(rs.getString("classdate"));
				bean.setClassdelete(rs.getString("classdelete"));
				vlist.addElement(bean);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt, rs);
		}
		return vlist;
	}
	
	public Vector<MemberBean> getRecentMember() {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		Vector<MemberBean> vlist = new Vector<MemberBean>();
		try {
			con = pool.getConnection();
			sql = "select * from member order by memberdate desc limit 0, 3";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				MemberBean bean = new MemberBean();
				bean.setMemberName(rs.getString("membername"));
				bean.setMemberId(rs.getString("memberid"));
				bean.setMemberBirth(rs.getString("memberbirth"));
				bean.setMemberSex(rs.getString("membersex"));
				bean.setMemberPhone(rs.getString("memberphone"));
				bean.setMemberdate(rs.getString("memberdate"));
				bean.setSignout(rs.getString("signout"));
				vlist.addElement(bean);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt, rs);
		}
		return vlist;
	}
}