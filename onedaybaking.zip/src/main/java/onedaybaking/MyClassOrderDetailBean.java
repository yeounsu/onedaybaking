package onedaybaking;

public class MyClassOrderDetailBean {
	private String cdMemberInfoImg;
	private String cdMemberNick;
	private String cdClassImg;
	private int cdClassKey;
	private String cdClassName;
	private String cdAddress;
	private String cdAddressDetail;
	private int cdClassTime;
	private String cdClassOrderDate;
	private int cdClassTotal;
	private int cdClassPrice;
	private String cdClassStatus;
	private String cdOrderDate;
	private int cdTotalOrderKey;
	private int cdOrderkey;
	
	public int getCdOrderkey() {
		return cdOrderkey;
	}
	public void setCdOrderkey(int cdOrderkey) {
		this.cdOrderkey = cdOrderkey;
	}
	public String getCdMemberInfoImg() {
		return cdMemberInfoImg;
	}
	public void setCdMemberInfoImg(String cdMemberInfoImg) {
		this.cdMemberInfoImg = cdMemberInfoImg;
	}
	public String getCdMemberNick() {
		return cdMemberNick;
	}
	public void setCdMemberNick(String cdMemberNick) {
		this.cdMemberNick = cdMemberNick;
	}
	public String getCdClassImg() {
		return cdClassImg;
	}
	public void setCdClassImg(String cdClassImg) {
		this.cdClassImg = cdClassImg;
	}
	public int getCdClassKey() {
		return cdClassKey;
	}
	public void setCdClassKey(int cdClassKey) {
		this.cdClassKey = cdClassKey;
	}
	public String getCdClassName() {
		return cdClassName;
	}
	public void setCdClassName(String cdClassName) {
		this.cdClassName = cdClassName;
	}
	public String getCdAddress() {
		return cdAddress;
	}
	public void setCdAddress(String cdAddress) {
		this.cdAddress = cdAddress;
	}
	public String getCdAddressDetail() {
		return cdAddressDetail;
	}
	public void setCdAddressDetail(String cdAddressDetail) {
		this.cdAddressDetail = cdAddressDetail;
	}
	public int getCdClassTime() {
		return cdClassTime;
	}
	public void setCdClassTime(int cdClassTime) {
		this.cdClassTime = cdClassTime;
	}
	public String getCdClassOrderDate() {
		return cdClassOrderDate;
	}
	public void setCdClassOrderDate(String cdClassOrderDate) {
		this.cdClassOrderDate = cdClassOrderDate;
	}
	public int getCdClassTotal() {
		return cdClassTotal;
	}
	public void setCdClassTotal(int cdClassTotal) {
		this.cdClassTotal = cdClassTotal;
	}
	public int getCdClassPrice() {
		return cdClassPrice;
	}
	public void setCdClassPrice(int cdClassPrice) {
		this.cdClassPrice = cdClassPrice;
	}
	public String getCdClassStatus() {
		return cdClassStatus;
	}
	public void setCdClassStatus(String cdClassStatus) {
		this.cdClassStatus = cdClassStatus;
	}
	public String getCdOrderDate() {
		return cdOrderDate;
	}
	public void setCdOrderDate(String cdOrderDate) {
		this.cdOrderDate = cdOrderDate;
	}
	public int getCdTotalOrderKey() {
		return cdTotalOrderKey;
	}
	public void setCdTotalOrderKey(int cdTotalOrderKey) {
		this.cdTotalOrderKey = cdTotalOrderKey;
	}
	
	
}
