package onedaybaking;

import java.io.File;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.LocalDate;
import java.util.Base64;
import java.util.Vector;

import javax.servlet.http.HttpServletRequest;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;

public class MemberMgr {
	DBConnectionMgr pool;
	//업로드 파일 저장 위치
	public static final String SAVEFOLDER="C:/Jsp/onedaybaking/src/main/webapp/img/member/";
	//업로드 파일 인코딩
	public static final String ENCODING="UTF-8";
	public static final int MAXSIZE = 1024 * 1024 * 20; //20MB
	public MemberMgr() {
		pool = DBConnectionMgr.getInstance();
	}
	
	//아이디 중복 확인
	public boolean checkId(String memberId) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		boolean flag = false;
		try {
			con = pool.getConnection();
			sql = "select memberId from member where memberId=?";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, memberId);

			rs = pstmt.executeQuery();
			if(rs.next()) flag = true;
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt, rs);
		}
		return flag;
	}
	// 비밀번호 해싱
	private String hashPassword(String password, byte[] salt) throws NoSuchAlgorithmException {
	    String passwordWithSalt = password + new String(salt);
	    MessageDigest digest = MessageDigest.getInstance("SHA-256");
	    byte[] hashBytes = digest.digest(passwordWithSalt.getBytes());
	    return Base64.getEncoder().encodeToString(hashBytes);
	}

	// 솔트 생성
	private byte[] generateSalt() {
	    SecureRandom random = new SecureRandom();
	    byte[] salt = new byte[16];
	    random.nextBytes(salt);
	    return salt;
	}
	//회원가입
	public boolean insertMember(MemberBean mBean) {
		Connection con = null;
		PreparedStatement pstmt = null;
		String sql = null;
		boolean flag = false;
		try {
			con = pool.getConnection();
			sql = "insert member values(?,?,?,?,?,?,?,?,?,?,?,null,now())";
			pstmt = con.prepareStatement(sql);
			// 비밀번호 해싱을 위한 솔트 생성
	        byte[] salt = generateSalt();
	        // 비밀번호 해싱
	        String hashedPassword = hashPassword(mBean.getMemberPwd(), salt);
	        
			pstmt.setString(1, mBean.getMemberId());
			pstmt.setString(2, hashedPassword);
			pstmt.setString(3, Base64.getEncoder().encodeToString(salt));
			pstmt.setString(4, mBean.getMemberName());
			pstmt.setString(5, mBean.getMemberBirth());
			pstmt.setString(6, mBean.getMemberSex());
			pstmt.setString(7, mBean.getMemberNick());
			String formatPhone = mBean.getMemberPhone();
			String phone="";
			if(formatPhone != null && formatPhone.length() == 11){
				phone = formatPhone.substring(0,3) +"-"+formatPhone.substring(3,7)+"-"+formatPhone.substring(7);
			}else {
				phone = formatPhone; 
			}
			pstmt.setString(8, phone);
			pstmt.setString(9, "N");
			pstmt.setInt(10, 1);
			pstmt.setString(11, "defaultImg.png");
			int cnt = pstmt.executeUpdate();
			pstmt.close();
			if(cnt == 1) {
				sql = "insert coupon values(null,?,?,now(),DATE_ADD(now(),INTERVAL 2 WEEK),'N',?)";
				pstmt = con.prepareStatement(sql);
				pstmt.setString(1, "첫 회원가입 감사 쿠폰");
				pstmt.setInt(2, 5000);
				pstmt.setString(3, mBean.getMemberId());
				
				if(pstmt.executeUpdate() == 1) flag = true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt);
		}
		return flag;
	}
	//로그인
	public boolean login(String memberId, String memberPwd) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		boolean flag = false;
		try {
			con = pool.getConnection();
			sql = "select memberId, passwordHash, salt from member where memberId=?";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, memberId);

			rs = pstmt.executeQuery();
			if(rs.next()) {
				String storedHashedPassword = rs.getString("passwordHash");
	            String storedSalt = rs.getString("salt");
	            
	            // 저장된 솔트를 다시 바이트 배열로 변환
	            byte[] saltBytes = Base64.getDecoder().decode(storedSalt);
	            
	            // 입력된 비밀번호를 해싱하여 저장된 해시된 비밀번호와 비교
	            String hashedPassword = hashPassword(memberPwd, saltBytes);
	            
	            if (hashedPassword.equals(storedHashedPassword)) {
	                // 비밀번호 일치 시 로그인 성공
	                
	            	flag = true;
	            }
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt, rs);
		}
		return flag;
	}
	//아이디 찾기
	public String idSearch(String memberName, String memberPhone, String memberBirth) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		String idResult = "";
		try {
			con = pool.getConnection();
			sql = "select memberId from member where memberName=? and memberPhone=? and memberBirth=?";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, memberName);
			pstmt.setString(2, memberPhone);
			pstmt.setString(3, memberBirth);

			rs = pstmt.executeQuery();
			if(rs.next()) idResult = rs.getString("memberId");
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt, rs);
		}
		return idResult;
	}
	//비밀번호 찾기
	public String passwordSearch(String memberId, String memberName) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		String passwordResult = "";
		try {
			con = pool.getConnection();
			sql = "select memberId from member where memberId=? and memberName=?";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, memberId);
			pstmt.setString(2, memberName);
			rs = pstmt.executeQuery();
			if(rs.next()) passwordResult = rs.getString("memberId");
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt, rs);
		}
		return passwordResult;
	}
	//새비밀번호 입력
	public boolean passwordUpdate(String memberId, String memberPwd) {
		Connection con = null;
		PreparedStatement pstmt = null;
		String sql = null;
		boolean flag = false;
		try {
			con = pool.getConnection();
			sql = "update member set passwordHash=?, salt=? where memberId=?";
			pstmt = con.prepareStatement(sql);
			// 비밀번호 해싱을 위한 솔트 생성
	        byte[] salt = generateSalt();
	        // 비밀번호 해싱
	        String hashedPassword = hashPassword(memberPwd, salt);
			pstmt.setString(1, hashedPassword);
			pstmt.setString(2, Base64.getEncoder().encodeToString(salt));
			pstmt.setString(3, memberId);

			if(pstmt.executeUpdate() == 1) flag = true;
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt);
		}
		return flag;
	}
	//회원정보 가져오기
	public MemberBean memberList(String memberId) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		MemberBean bean = new MemberBean();
		try {
			con = pool.getConnection();
			sql = "select * from member where memberId=?";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, memberId);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				bean.setMemberId(rs.getString("memberId"));
				bean.setMemberPwd(rs.getString("passwordHash"));
				bean.setSalt(rs.getString("salt"));
				bean.setMemberName(rs.getString("memberName"));
				bean.setMemberBirth(rs.getString("memberBirth"));
				bean.setMemberSex(rs.getString("memberSex"));
				bean.setMemberNick(rs.getString("memberNick"));
				bean.setMemberPhone(rs.getString("memberPhone"));
				bean.setSignout(rs.getString("signout"));
				bean.setAuth(rs.getInt("auth"));
				bean.setMemberInfoImg(rs.getString("memberInfoImg"));
				bean.setMemberInfo(rs.getString("memberInfo"));
				bean.setMemberdate(rs.getString("memberdate"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt, rs);
		}
		return bean;
	}
	//회원수정 비밀번호 확인
	public boolean passwordCheck(String memberId, String memberPwd) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		boolean flag = false;
		try {
			con = pool.getConnection();
			sql = "select passwordHash, salt from member where memberId=?";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, memberId);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				String storedHashedPassword = rs.getString("passwordHash");
	            String storedSalt = rs.getString("salt");
	            // 저장된 솔트를 다시 바이트 배열로 변환
	            byte[] saltBytes = Base64.getDecoder().decode(storedSalt);
	            // 입력된 비밀번호를 해싱하여 저장된 해시된 비밀번호와 비교
	            String hashedPassword = hashPassword(memberPwd, saltBytes);
	            if (hashedPassword.equals(storedHashedPassword)) {
	            	flag = true;
	            }
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt, rs);
		}
		return flag;
	}
	//회원정보 수정
	public boolean memberUpdate(MemberAddressBean maBean, MemberBean mBean) {
		Connection con = null;
		PreparedStatement pstmt = null;
		String sql = null;
		boolean flag = false;
		try {
			con = pool.getConnection();
			sql = "update member set memberName=?, memberNick=?, memberPhone=? where memberId=?";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, mBean.getMemberName());
			pstmt.setString(2, mBean.getMemberNick());
			String formatPhone = mBean.getMemberPhone();
			String phone="";
			if(formatPhone != null && formatPhone.length() == 11){
				phone = formatPhone.substring(0,3) +"-"+formatPhone.substring(3,7)+"-"+formatPhone.substring(7);
			}else {
				phone = formatPhone; 
			}
			pstmt.setString(3, phone);
			pstmt.setString(4, mBean.getMemberId());
			int cnt = pstmt.executeUpdate();
			pstmt.close();
			
			if(cnt == 1) {
				sql="select memberId from memberaddress where memberId=?";
				pstmt = con.prepareStatement(sql);
				pstmt.setString(1, mBean.getMemberId());
				ResultSet rs = pstmt.executeQuery();
				if(!rs.next()) {
					sql = "insert memberaddress values(null,null,?,?,?,null,null,null,?)";
					pstmt = con.prepareStatement(sql);
					pstmt.setString(1, maBean.getZipcode());
					pstmt.setString(2, maBean.getAddress());
					pstmt.setString(3, maBean.getAddressDetail());
					pstmt.setString(4, mBean.getMemberId());
				} else {
					sql = "update memberaddress set zipcode=?, address=?, addressDetail=? where memberId=?";
					pstmt = con.prepareStatement(sql);
					pstmt.setString(1, maBean.getZipcode());
					pstmt.setString(2, maBean.getAddress());
					pstmt.setString(3, maBean.getAddressDetail());
					pstmt.setString(4, maBean.getMemberId());
				}
			
				if(pstmt.executeUpdate() == 1) flag = true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt);
		}
		return flag;
	}
	//기본 배송지 정보 가져오기{
	public MemberAddressBean AddressList(String memberId) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		MemberAddressBean maBean = new MemberAddressBean();
		try {
			con = pool.getConnection();
			sql = "select * from memberAddress where memberId=?";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, memberId);

			rs = pstmt.executeQuery();
			if(rs.next()) {
				maBean.setAddrKey(rs.getInt(1));
				maBean.setName(rs.getString(2));
				maBean.setZipcode(rs.getString(3));
				maBean.setAddress(rs.getString(4));
				maBean.setAddressDetail(rs.getString(5));
				maBean.setPhone(rs.getString(6));
				maBean.setRequest(rs.getString(7));
				maBean.setDef(rs.getInt(7));
				maBean.setMemberId(rs.getString(8));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt, rs);
		}
		return maBean;
	}
	//강사소개 업데이트
	public boolean teacherInfo(HttpServletRequest req, String memberId) {
		Connection con = null;
		PreparedStatement pstmt = null;
		String sql = null;
		boolean flag = false;
		try {
			con = pool.getConnection();
			MultipartRequest multi = new MultipartRequest(req,SAVEFOLDER, MAXSIZE, ENCODING, new DefaultFileRenamePolicy());
			String memberInfoImg = multi.getFilesystemName("memberInfoImg");
			String memberInfo = multi.getParameter("memberInfo");
			if(memberInfoImg != null && !memberInfoImg.equals("")) {
				//기존 업로드도 수정 : 기존에 파일 삭제
				MemberBean mBean = memberList(memberId);
				String infoImg = mBean.getMemberInfoImg();
				if(infoImg != null && !infoImg.equals("")) {
					File img = new File(SAVEFOLDER + infoImg);
					if(img.exists()) {
						if (!infoImg.equals("defaultImg.png"))
							UtilMgr.delete(SAVEFOLDER + infoImg);
					}
				}
				sql = "update member set memberInfo=?, memberInfoImg=? where memberId=?";
				pstmt = con.prepareStatement(sql);
				pstmt.setString(1, memberInfo);
				pstmt.setString(2, memberInfoImg);
				pstmt.setString(3, memberId);
			}else {
				sql = "update member set memberInfo=? where memberId=?";
				pstmt = con.prepareStatement(sql);
				pstmt.setString(1, memberInfo);
				pstmt.setString(2, memberId);
			}
			//System.out.println(memberInfo);
			if( pstmt.executeUpdate() == 1) flag = true;
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt);
		}
		return flag;
	}
	
	//나의 클래스 문의내역 불러오기
	public Vector<MyInquireClassBean> myInquireClassList(String memberId) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		ResultSet rss = null;
		String sql = null;
		Vector<MyInquireClassBean> vlist = new Vector<MyInquireClassBean>();
		try {
			con = pool.getConnection();
			sql = "select cb.classBoardKey, m.memberInfoImg, c.classKey, c.classname , cb.commentdate, cb.commentcontent, cb.commentimg1, cb.commentimg2, cb.commentimg3 "
					+ "from oneday.member m "
					+ "left outer join oneday.class c "
					+ "on m.memberId = c.memberId "
					+ "left outer join oneday.classboard cb "
					+ "on c.classkey = cb.classkey "
					+ "where cb.memberId=? and cb.commenttype='1' "
					+ "order by classboardkey desc";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, memberId);;

			rs = pstmt.executeQuery();
			while(rs.next()) {
				MyInquireClassBean mcBean = new MyInquireClassBean();
				mcBean.setClassBoardKey(rs.getInt(1));
				mcBean.setMemberInfoImg(rs.getString(2));
				mcBean.setClassKey(rs.getInt(3));
				mcBean.setName(rs.getString(4));
				mcBean.setCommentDate(rs.getString(5));
				mcBean.setCommentContent(rs.getString(6));
				mcBean.setCommentimg1(rs.getString(7));
				mcBean.setCommentimg2(rs.getString(8));
				mcBean.setCommentimg3(rs.getString(9));
				
				sql = "select cb.commentcontent, cb.commentdate, m.membernick "
						+ "from oneday.classboard cb "
						+ "left outer join oneday.member m "
						+ "on m.memberid = cb.memberid "
						+ "where cb.boardkey =? and cb.commenttype='0'";
				pstmt = con.prepareStatement(sql);
				pstmt.setInt(1, rs.getInt(1));
				rss = pstmt.executeQuery();
				if (rss.next()) {
					mcBean.setReplyComment(rss.getString("commentcontent"));
					mcBean.setReplyNick(rss.getString("membernick"));
					mcBean.setReplyDate(rss.getString("commentdate"));
				}
				
				vlist.addElement(mcBean);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt, rs);
		}
		return vlist;
	}
	//나의 상품 문의내역 불러오기
		public Vector<MyInquireItemBean> myInquireItemList(String memberId) {
			Connection con = null;
			PreparedStatement pstmt = null;
			ResultSet rs = null;
			ResultSet rss = null;
			String sql = null;
			Vector<MyInquireItemBean> vlist = new Vector<MyInquireItemBean>();
			try {
				con = pool.getConnection();
				
				sql = "select ib.itemBoardKey, m.memberInfoImg, i.itemKey, i.itemname , ib.commentdate, ib.commentcontent, ib.commentimg1, ib.commentimg2, ib.commentimg3 "
						+ "from oneday.member m "
						+ "left outer join oneday.item i "
						+ "on m.memberId = i.memberId "
						+ "left outer join oneday.Itemboard ib "
						+ "on i.itemkey = ib.itemkey "
						+ "where ib.memberId=? and ib.commenttype='1' "
						+ "order by itemboardkey desc";
				pstmt = con.prepareStatement(sql);
				pstmt.setString(1, memberId);;

				rs = pstmt.executeQuery();
				while(rs.next()) {
					MyInquireItemBean miBean = new MyInquireItemBean();
					miBean.setItemBoardKey(rs.getInt(1));
					miBean.setMemberInfoImg(rs.getString(2));
					miBean.setItemKey(rs.getInt(3));
					miBean.setName(rs.getString(4));
					miBean.setCommentDate(rs.getString(5));
					miBean.setCommentContent(rs.getString(6));
					miBean.setCommentimg1(rs.getString(7));
					miBean.setCommentimg2(rs.getString(8));
					miBean.setCommentimg3(rs.getString(9));
					
					sql = "select ib.commentcontent, ib.commentdate, m.membernick "
							+ "from itemboard ib "
							+ "left outer join oneday.member m "
							+ "on m.memberid = ib.memberid "
							+ "where ib.boardkey =? and ib.commenttype='0'";
					pstmt = con.prepareStatement(sql);
					pstmt.setInt(1, rs.getInt(1));
					rss = pstmt.executeQuery();
					if (rss.next()) {
						miBean.setReplyComment(rss.getString("commentcontent"));
						miBean.setReplyNick(rss.getString("membernick"));
						miBean.setReplyDate(rss.getString("commentdate"));
						
					}
					
					vlist.addElement(miBean);
				}
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				pool.freeConnection(con, pstmt, rs);
			}
			return vlist;
		}
		//상품 문의내역 삭제(답변까지 모두 삭제)
		public void itemInquireDelete(int boardKey) {
			Connection con = null;
			PreparedStatement pstmt = null;
			PreparedStatement pstmts = null;
			String sql = null;
			try {
				con = pool.getConnection();
				sql = "delete from itemBoard where itemBoardKey=?";
				pstmt = con.prepareStatement(sql);
				pstmt.setInt(1, boardKey);
				pstmt.executeUpdate();
				
				sql = "delete from itemBoard where boardkey=?";
				pstmts = con.prepareStatement(sql);
				pstmts.setInt(1, boardKey);
				pstmts.executeUpdate();
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				pool.freeConnection(con, pstmt);
			}
		}
		//클래스 문의내역 삭제(답변까지 모두 삭제)
		public void classInquireDelete(int boardKey) {
			Connection con = null;
			PreparedStatement pstmt = null;
			PreparedStatement pstmts = null;
			String sql = null;
			try {
				con = pool.getConnection();
				sql = "delete from classBoard where classBoardKey=?";
				pstmt = con.prepareStatement(sql);
				pstmt.setInt(1, boardKey);
				pstmt.executeUpdate();
				
				sql = "delete from classBoard where boardkey=?";
					pstmts = con.prepareStatement(sql);
					pstmts.setInt(1, boardKey);
					pstmts.executeUpdate();
				} catch (Exception e) {
					e.printStackTrace();
				} finally {
					pool.freeConnection(con, pstmt);
				}
			}
		//수강 전 후 구분하여 classStatus N -> Y로 바꾸기
		public void updateExpiredReservations() {
	        Connection con = null;
			PreparedStatement pstmt = null;
			String sql = null;
			try {
				con = pool.getConnection();
				LocalDate currentDate = LocalDate.now();
				sql = "select * from oneday.classorderdetail cod "
						+ "left outer join oneday.classorder co "
						+ "on co.classorderkey = cod.classorderkey "
						+ "where co.classorderdate < CURDATE() and classstatus='N' ";
				pstmt = con.prepareStatement(sql);

				pstmt.executeUpdate();
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				pool.freeConnection(con, pstmt);
			}
			return;
	    }

		//내 클래스 수강 전 예약내역 불러오기
		public Vector<MyClassOrderDetailBean> myClassOrderDetail(String memberId, String orderMonth){
			Connection con = null;
			PreparedStatement pstmt = null;
			ResultSet rs = null;
			String sql = null;
			Vector<MyClassOrderDetailBean> vlist = new Vector<MyClassOrderDetailBean>();
			try {
				con = pool.getConnection();
				sql = "select m.memberInfoImg, m.memberNick, c.classImg1, c.classKey, c.className, c.address, c.addressDetail, c.classTime, "
						+ "co.classOrderDate, co.classTotal, co.classPrice, "
						+ "cod.classStatus, tto.orderDate, tto.totalOrderKey, co.classorderkey  "
						+ "from oneday.totalOrder tto "
						+ "left outer join oneday.classOrder co on tto.classOrderKey = co.classOrderKey "
						+ "left outer join oneday.classOrderDetail cod on co.classOrderKey = cod.classOrderKey "
						+ "left outer join oneday.class c on co.classKey = c.classKey "
						+ "left outer join oneday.member m on c.memberId = m.memberId "
						+ "where tto.memberId=? and classOrderDate like ? and cod.classStatus='N' "
						+ "order by co.classOrderDate desc";
				pstmt = con.prepareStatement(sql);
				pstmt.setString(1, memberId);
				pstmt.setString(2, orderMonth+"%");
				rs = pstmt.executeQuery();
				
				while(rs.next()) {
					MyClassOrderDetailBean mcodBean = new MyClassOrderDetailBean();
					mcodBean.setCdMemberInfoImg(rs.getString("memberInfoImg"));
					mcodBean.setCdMemberNick(rs.getString("memberNick"));
					mcodBean.setCdClassImg(rs.getString("classImg1"));
					mcodBean.setCdClassKey(rs.getInt("classKey"));
					mcodBean.setCdClassName(rs.getString("className"));
					mcodBean.setCdOrderkey(rs.getInt("classorderkey"));
					mcodBean.setCdAddress(rs.getString("address"));
					mcodBean.setCdAddressDetail(rs.getString("addressDetail"));
					mcodBean.setCdClassTime(rs.getInt("classTime"));
					mcodBean.setCdClassOrderDate(rs.getString("classOrderDate"));
					mcodBean.setCdClassTotal(rs.getInt("classTotal"));
					mcodBean.setCdClassPrice(rs.getInt("classPrice"));
					mcodBean.setCdClassStatus(rs.getString("classStatus"));
					mcodBean.setCdOrderDate(rs.getString("orderDate"));
					mcodBean.setCdTotalOrderKey(rs.getInt("totalOrderKey"));
					vlist.addElement(mcodBean);
				}
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				pool.freeConnection(con, pstmt, rs);
			}
			return vlist;
		}
		//내 클래스 수강 후 예약내역 불러오기
		public Vector<MyClassOrderDetailBean> myClassOrderFinishDetail(String memberId, String orderMonth){
			Connection con = null;
			PreparedStatement pstmt = null;
			ResultSet rs = null;
			String sql = null;
			Vector<MyClassOrderDetailBean> vlist = new Vector<MyClassOrderDetailBean>();
			try {
				con = pool.getConnection();
				sql = "select m.memberInfoImg, m.memberNick, c.className, c.address, c.addressDetail, c.classTime, "
						+ "co.classOrderDate, co.classTotal, co.classPrice, "
						+ "cod.classStatus, tto.orderDate, tto.totalOrderKey "
						+ "from oneday.totalOrder tto "
						+ "left outer join oneday.classOrder co on tto.classOrderKey = co.classOrderKey "
						+ "left outer join oneday.classOrderDetail cod on co.classOrderKey = cod.classOrderKey "
						+ "left outer join oneday.class c on co.classKey = c.classKey "
						+ "left outer join oneday.member m on c.memberId = m.memberId "
						+ "where tto.memberId=? and classOrderDate like ? and cod.classStatus='Y' "
						+ "order by co.classOrderDate desc";
				pstmt = con.prepareStatement(sql);
				pstmt.setString(1, memberId);
				pstmt.setString(2, orderMonth+"%");
				rs = pstmt.executeQuery();
				
				while(rs.next()) {
					MyClassOrderDetailBean mcodBean = new MyClassOrderDetailBean();
					mcodBean.setCdMemberInfoImg(rs.getString("memberInfoImg"));
					mcodBean.setCdMemberNick(rs.getString("memberNick"));
					mcodBean.setCdClassName(rs.getString("className"));
					mcodBean.setCdAddress(rs.getString("address"));
					mcodBean.setCdAddressDetail(rs.getString("addressDetail"));
					mcodBean.setCdClassTime(rs.getInt("classTime"));
					mcodBean.setCdClassOrderDate(rs.getString("classOrderDate"));
					mcodBean.setCdClassTotal(rs.getInt("classTotal"));
					mcodBean.setCdClassPrice(rs.getInt("classPrice"));
					mcodBean.setCdClassStatus(rs.getString("classStatus"));
					mcodBean.setCdOrderDate(rs.getString("orderDate"));
					mcodBean.setCdTotalOrderKey(rs.getInt("totalOrderKey"));
					vlist.addElement(mcodBean);
				}
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				pool.freeConnection(con, pstmt, rs);
			}
			return vlist;
		}
		//내 클래스 이름 목록
				public Vector<ClassBean> myClassList(String memberId){
					Connection con = null;
					PreparedStatement pstmt = null;
					ResultSet rs = null;
					String sql = null;
					Vector<ClassBean> vlist = new Vector<ClassBean>();
					try {
						con = pool.getConnection();
						sql = "select classkey, classname from class where memberId=? ";
						pstmt = con.prepareStatement(sql);
						pstmt.setString(1, memberId);

						rs = pstmt.executeQuery();
						while(rs.next()) {
							ClassBean cBean = new ClassBean();
							cBean.setClasskey(rs.getInt(1));
							cBean.setClassname(rs.getString(2));
							vlist.addElement(cBean);
						}
					} catch (Exception e) {
						e.printStackTrace();
					} finally {
						pool.freeConnection(con, pstmt, rs);
					}
					return vlist;
				}
		//내 클래스 관리
		public Vector<MyClassCareBean> myClassCare(String className, String sdate){
			Connection con = null;
			PreparedStatement pstmt = null;
			ResultSet rs = null;
			String sql = null;
			Vector<MyClassCareBean> vlist = new Vector<MyClassCareBean>();
			try {
				con = pool.getConnection();
				sql = "select co.classOrderKey, co.classTotal, co.classOrderDate, m.memberName, m.memberPhone "
						+ "from oneday.class c "
						+ "left outer join oneday.classOrder co "
						+ "on co.classKey = c.classKey "
						+ "left outer join oneday.member m "
						+ "on m.memberId = co.memberId "
						+ "where c.className=? and co.classOrderDate=? ";
				pstmt = con.prepareStatement(sql);
				pstmt.setString(1, className);
				pstmt.setString(2, sdate);

				rs = pstmt.executeQuery();
				while(rs.next()) {
					MyClassCareBean ccBean = new MyClassCareBean();
					ccBean.setClassOrderKey(rs.getInt("classOrderKey"));
					ccBean.setClassTotal(rs.getInt("classTotal"));
					ccBean.setClassOrderDate(rs.getString("ClassOrderDate"));
					ccBean.setMemberName(rs.getString("memberName"));
					ccBean.setMemberPhone(rs.getString("memberPhone"));
					vlist.addElement(ccBean);
				}
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				pool.freeConnection(con, pstmt, rs);
			}
			return vlist; 
		}
		//내 상품 이름 목록
		public Vector<ItemBean> myItemList(String memberId){
			Connection con = null;
			PreparedStatement pstmt = null;
			ResultSet rs = null;
			String sql = null;
			Vector<ItemBean> vlist = new Vector<ItemBean>();
			try {
				con = pool.getConnection();
				sql = "select itemkey, itemname from item where memberId=? ";
				pstmt = con.prepareStatement(sql);
				pstmt.setString(1, memberId);

				rs = pstmt.executeQuery();
				while(rs.next()) {
					ItemBean iBean = new ItemBean();
					iBean.setItemkey(rs.getInt(1));
					iBean.setItemname(rs.getString(2));
					vlist.addElement(iBean);
				}
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				pool.freeConnection(con, pstmt, rs);
			}
			return vlist;
		}
		//내 상품 관리 (옵션빼고)
		public Vector<MyItemCareBean> myItemCare(String memberId, String sdate, int itemkey){
			Connection con = null;
			PreparedStatement pstmt = null;
			ResultSet rs = null;
			String sql = null;
			Vector<MyItemCareBean> vlist = new Vector<MyItemCareBean>();
			try {
				con = pool.getConnection();
				sql = "select tto.totalorderkey, tto.orderdate, tto.memberid, "
						+ "i.itemname, i.itemkey, "
						+ "io.ordername, io.orderphone, "
						+ "iod.itemcount, iod.itemoption, iod.itemorderstate, iod.itemorderdetailkey  "
						+ "from oneday.item i "
						+ "left outer join oneday.itemorderdetail iod on i.itemkey = iod.itemkey "
						+ "left outer join oneday.itemorder io on iod.orderkey = io.itemorderkey "
						+ "left outer join oneday.totalorder tto on iod.orderkey = tto.itemorderkey "
						+ "where i.memberid=? and tto.orderdate=? and iod.itemkey=? ";
				pstmt = con.prepareStatement(sql);
				pstmt.setString(1, memberId);
				pstmt.setString(2, sdate);
				pstmt.setInt(3, itemkey);
				rs = pstmt.executeQuery();
				
				while(rs.next()) {
					MyItemCareBean icBean = new MyItemCareBean();
					icBean.setTotalOrderKey(rs.getInt(1));
					icBean.setOrderdate(rs.getString(2));
					icBean.setOrderMemberId(rs.getString(3));
					icBean.setOrderItemName(rs.getString(4));
					icBean.setItemKey(rs.getInt(5));
					icBean.setOrderName(rs.getString(6));
					icBean.setOrderPhone(rs.getString(7));
					icBean.setItemCount(rs.getInt(8));
					String option = rs.getString(9);
					String os[] = new String[option.length()];
					for (int i = 0; i < os.length; i++) {
						os[i] = option.substring(i, i + 1);
					}
					icBean.setItemOption(os);
					icBean.setItemOrderState(rs.getString(10));
					icBean.setItemOrderDetailKey(rs.getInt(11));
					vlist.addElement(icBean);
				}
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				pool.freeConnection(con, pstmt, rs);
			}
			return vlist;
		}
		//내 상품 옵션 불러오기
		public ItemOptionBean getItemOption(int itemKey){
			Connection con = null;
			PreparedStatement pstmt = null;
			ResultSet rs = null;
			String sql = null;
			ItemOptionBean ioBean = new ItemOptionBean();
			try {
				con = pool.getConnection();
				sql = "select * from itemoption where itemkey=? ";
				pstmt = con.prepareStatement(sql);
				pstmt.setInt(1, itemKey);

				rs = pstmt.executeQuery();
				if(rs.next()) {
					ioBean.setOptionKey(rs.getInt(1));
					ioBean.setItemOption1(rs.getString(2));
					ioBean.setItemOption2(rs.getString(3));
					ioBean.setItemOption3(rs.getString(4));
					ioBean.setItemOption4(rs.getString(5));
					ioBean.setItemOption5(rs.getString(6));
					ioBean.setItemOption6(rs.getString(7));
					ioBean.setItemOption7(rs.getString(8));
					ioBean.setItemOption8(rs.getString(9));
					ioBean.setItemOption9(rs.getString(10));
					ioBean.setItemOption10(rs.getString(11));
					ioBean.setItemsOption1(rs.getString(12));
					ioBean.setItemsOption2(rs.getString(13));
					ioBean.setItemsOption3(rs.getString(14));
					ioBean.setItemsOption4(rs.getString(15));
					ioBean.setItemsOption5(rs.getString(16));
					ioBean.setItemsOption6(rs.getString(17));
					ioBean.setItemsOption7(rs.getString(18));
					ioBean.setItemsOption8(rs.getString(19));
					ioBean.setItemsOption9(rs.getString(20));
					ioBean.setItemsOption10(rs.getString(21));
					ioBean.setItemKey(rs.getInt(22));
				}
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				pool.freeConnection(con, pstmt, rs);
			}
			return ioBean;
		}
		//상품 상태 변경
		public boolean updateStatus(int itemOrderDetailKey, String status) {
			Connection con = null;
			PreparedStatement pstmt = null;
			String sql = null;
			boolean flag = false;
			try {
				con = pool.getConnection();
				sql = "update itemorderdetail set itemorderstate=? where itemorderdetailKey=?";
				pstmt = con.prepareStatement(sql);
				pstmt.setString(1, status);
				pstmt.setInt(2, itemOrderDetailKey);

				if( pstmt.executeUpdate() == 1) flag = true;
				
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				pool.freeConnection(con, pstmt);
			}
			return flag;
		}
		
		//나의 상품 후기내역 불러오기
				public Vector<MyInquireItemBean> myReviewItemList(String memberId) {
					Connection con = null;
					PreparedStatement pstmt = null;
					ResultSet rs = null;
					ResultSet rss = null;
					String sql = null;
					Vector<MyInquireItemBean> vlist = new Vector<MyInquireItemBean>();
					try {
						con = pool.getConnection();
						
						sql = "select ib.itemBoardKey, m.memberInfoImg, i.itemKey, i.itemname , ib.commentdate, ib.commentcontent, ib.commentimg1, ib.commentimg2, ib.commentimg3 "
								+ "from oneday.member m "
								+ "left outer join oneday.item i "
								+ "on m.memberId = i.memberId "
								+ "left outer join oneday.Itemboard ib "
								+ "on i.itemkey = ib.itemkey "
								+ "where ib.memberId=? and ib.commenttype='2' "
								+ "order by itemboardkey desc";
						pstmt = con.prepareStatement(sql);
						pstmt.setString(1, memberId);;

						rs = pstmt.executeQuery();
						while(rs.next()) {
							MyInquireItemBean miBean = new MyInquireItemBean();
							miBean.setItemBoardKey(rs.getInt(1));
							miBean.setMemberInfoImg(rs.getString(2));
							miBean.setItemKey(rs.getInt(3));
							miBean.setName(rs.getString(4));
							miBean.setCommentDate(rs.getString(5));
							miBean.setCommentContent(rs.getString(6));
							miBean.setCommentimg1(rs.getString(7));
							miBean.setCommentimg2(rs.getString(8));
							miBean.setCommentimg3(rs.getString(9));
							vlist.addElement(miBean);
						}
					} catch (Exception e) {
						e.printStackTrace();
					} finally {
						pool.freeConnection(con, pstmt, rs);
					}
					return vlist;
				}
		//나의 클래스 후기내역 불러오기
		public Vector<MyInquireClassBean> myReviewClassList(String memberId) {
			Connection con = null;
			PreparedStatement pstmt = null;
			ResultSet rs = null;
			ResultSet rss = null;
			String sql = null;
			Vector<MyInquireClassBean> vlist = new Vector<MyInquireClassBean>();
			try {
				con = pool.getConnection();
				sql = "select cb.classBoardKey, m.memberInfoImg, c.classKey, c.classname , cb.commentdate, cb.commentcontent, cb.commentimg1, cb.commentimg2, cb.commentimg3 "
						+ "from oneday.member m "
						+ "left outer join oneday.class c "
						+ "on m.memberId = c.memberId "
						+ "left outer join oneday.classboard cb "
						+ "on c.classkey = cb.classkey "
						+ "where cb.memberId=? and cb.commenttype='2' "
						+ "order by classboardkey desc";
				pstmt = con.prepareStatement(sql);
				pstmt.setString(1, memberId);;

				rs = pstmt.executeQuery();
				while(rs.next()) {
					MyInquireClassBean mcBean = new MyInquireClassBean();
					mcBean.setClassBoardKey(rs.getInt(1));
					mcBean.setMemberInfoImg(rs.getString(2));
					mcBean.setClassKey(rs.getInt(3));
					mcBean.setName(rs.getString(4));
					mcBean.setCommentDate(rs.getString(5));
					mcBean.setCommentContent(rs.getString(6));
					mcBean.setCommentimg1(rs.getString(7));
					mcBean.setCommentimg2(rs.getString(8));
					mcBean.setCommentimg3(rs.getString(9));
					vlist.addElement(mcBean);
				}
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				pool.freeConnection(con, pstmt, rs);
			}
			return vlist;
		}
		
		//회원탈퇴
		public boolean signOut(String memberId) {
			Connection con = null;
			PreparedStatement pstmt = null;
			String sql = null;
			boolean flag = false;
			try {
				con = pool.getConnection();
				sql = "update member set signout='Y' where memberId=? ";
				pstmt = con.prepareStatement(sql);
				pstmt.setString(1, memberId);

				if(pstmt.executeUpdate() == 1) flag = true;
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				pool.freeConnection(con, pstmt);
			}
			return flag;
		}
	}
