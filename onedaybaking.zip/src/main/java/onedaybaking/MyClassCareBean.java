package onedaybaking;

public class MyClassCareBean {
	private int classOrderKey;
	private String className;
	private int classTotal;
	private String classOrderDate;
	private String memberName;
	private String memberPhone;
	
	public int getClassOrderKey() {
		return classOrderKey;
	}
	public void setClassOrderKey(int classOrderKey) {
		this.classOrderKey = classOrderKey;
	}
	public String getClassName() {
		return className;
	}
	public void setClassName(String className) {
		this.className = className;
	}
	public int getClassTotal() {
		return classTotal;
	}
	public void setClassTotal(int classTotal) {
		this.classTotal = classTotal;
	}
	public String getClassOrderDate() {
		return classOrderDate;
	}
	public void setClassOrderDate(String classOrderDate) {
		this.classOrderDate = classOrderDate;
	}
	public String getMemberName() {
		return memberName;
	}
	public void setMemberName(String memberName) {
		this.memberName = memberName;
	}
	public String getMemberPhone() {
		return memberPhone;
	}
	public void setMemberPhone(String memberPhone) {
		this.memberPhone = memberPhone;
	}
	
	
}
