package onedaybaking;

public class boardBean {

	private int num;
	private String ename;
	private String kname;
	private String usevalue;
	private String listvalue;
	private String readvalue;
	private String writevalue;
	
	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public String getKname() {
		return kname;
	}
	public void setKname(String kname) {
		this.kname = kname;
	}
	public String getUsevalue() {
		return usevalue;
	}
	public void setUsevalue(String usevalue) {
		this.usevalue = usevalue;
	}
	public String getListvalue() {
		return listvalue;
	}
	public void setListvalue(String listvalue) {
		this.listvalue = listvalue;
	}
	public String getReadvalue() {
		return readvalue;
	}
	public void setReadvalue(String readvalue) {
		this.readvalue = readvalue;
	}
	public String getWritevalue() {
		return writevalue;
	}
	public void setWritevalue(String writevalue) {
		this.writevalue = writevalue;
	}
	
}
