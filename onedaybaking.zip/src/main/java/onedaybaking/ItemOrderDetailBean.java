package onedaybaking;

public class ItemOrderDetailBean {
	
	private int itemOrderDetailKey;
	private int itemCount;
	private int itemPrice;
	private String itemOrderState;
	private int itemOrderkey;
	private int ItemKey;
	private String orderItemOption[];
	private String orderItemImg;
	private String orderItemName;
	private int totalItemCount;
	
	public int getItemOrderDetailKey() {
		return itemOrderDetailKey;
	}
	public void setItemOrderDetailKey(int itemOrderDetailKey) {
		this.itemOrderDetailKey = itemOrderDetailKey;
	}
	public int getItemCount() {
		return itemCount;
	}
	public void setItemCount(int itemCount) {
		this.itemCount = itemCount;
	}
	public int getItemPrice() {
		return itemPrice;
	}
	public void setItemPrice(int itemPrice) {
		this.itemPrice = itemPrice;
	}
	public String getItemOrderState() {
		return itemOrderState;
	}
	public void setItemOrderState(String itemOrderState) {
		this.itemOrderState = itemOrderState;
	}
	public int getItemOrderkey() {
		return itemOrderkey;
	}
	public void setItemOrderkey(int itemOrderkey) {
		this.itemOrderkey = itemOrderkey;
	}
	public int getItemKey() {
		return ItemKey;
	}
	public void setItemKey(int itemKey) {
		ItemKey = itemKey;
	}
	public String[] getOrderItemOption() {
		return orderItemOption;
	}
	public void setOrderItemOption(String[] orderItemOption) {
		this.orderItemOption = orderItemOption;
	}
	
	public String getOrderItemImg() {
		return orderItemImg;
	}
	public void setOrderItemImg(String orderItemImg) {
		this.orderItemImg = orderItemImg;
	}
	public String getOrderItemName() {
		return orderItemName;
	}
	public void setOrderItemName(String orderItemName) {
		this.orderItemName = orderItemName;
	}
	public int getTotalItemCount() {
		return totalItemCount;
	}
	public void setTotalItemCount(int totalItemCount) {
		this.totalItemCount = totalItemCount;
	}
	
}
