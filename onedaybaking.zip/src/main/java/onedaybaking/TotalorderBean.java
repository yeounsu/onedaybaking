package onedaybaking;

public class TotalorderBean {
	
	private int totalorderkey;
	private int totalprice;
	private String ordercard;
	private String orderdate;
	private String memberid;
	private int classorderkey;
	private int itemorderkey;
	private String ordername;
	private String membername;
	private String phone;
	private String orderstate; 
	
	public int getTotalorderkey() {
		return totalorderkey;
	}
	public void setTotalorderkey(int totalorderkey) {
		this.totalorderkey = totalorderkey;
	}
	public int getTotalprice() {
		return totalprice;
	}
	public void setTotalprice(int totalprice) {
		this.totalprice = totalprice;
	}
	public String getOrdercard() {
		return ordercard;
	}
	public void setOrdercard(String ordercard) {
		this.ordercard = ordercard;
	}
	public String getOrderdate() {
		return orderdate;
	}
	public void setOrderdate(String orderdate) {
		this.orderdate = orderdate;
	}
	public String getMemberid() {
		return memberid;
	}
	public void setMemberid(String memberid) {
		this.memberid = memberid;
	}
	public int getClassorderkey() {
		return classorderkey;
	}
	public void setClassorderkey(int classorderkey) {
		this.classorderkey = classorderkey;
	}
	public int getItemorderkey() {
		return itemorderkey;
	}
	public void setItemorderkey(int itemorderkey) {
		this.itemorderkey = itemorderkey;
	}
	public String getOrdername() {
		return ordername;
	}
	public void setOrdername(String ordername) {
		this.ordername = ordername;
	}
	public String getMembername() {
		return membername;
	}
	public void setMembername(String membername) {
		this.membername = membername;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getOrderstate() {
		return orderstate;
	}
	public void setOrderstate(String orderstate) {
		this.orderstate = orderstate;
	}
}