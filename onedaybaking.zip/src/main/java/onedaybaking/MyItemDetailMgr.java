package onedaybaking;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Vector;

public class MyItemDetailMgr {
	DBConnectionMgr pool;
	
	public MyItemDetailMgr() {
		pool = DBConnectionMgr.getInstance();
	}
	//내 구매상품 날짜별 목록
	public Vector<ItemOrderBean> itemDateList(String memberId, String orderMonth){
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		Vector<ItemOrderBean> vlist = new Vector<ItemOrderBean>();
		try {
			con = pool.getConnection();
			sql = "select io.itemorderdate, io.itemorderkey, io.memberid "
					+ "from oneday.itemorder io "
					+ "where io.memberid=? and io.itemorderdate like ? order by itemorderdate desc";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, memberId);
			pstmt.setString(2, orderMonth+"%");
			
			rs = pstmt.executeQuery();
			while(rs.next()) {
				ItemOrderBean ioBean = new ItemOrderBean();
				ioBean.setItemOrderKey(rs.getInt("itemorderkey"));
				ioBean.setItemOrderDate(rs.getString("itemorderdate"));
				ioBean.setOrderMemberId(rs.getString("memberid"));
				vlist.addElement(ioBean);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt, rs);
		}
		return vlist;
	}
	//내 구매상품 결제정보, 배송지 목록
	public Vector<MyItemTotalOrderDetailBean> itemTotalOrderDetailList(int itemOrderKey){
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		Vector<MyItemTotalOrderDetailBean> vlist = new Vector<MyItemTotalOrderDetailBean>();
		try {
			con = pool.getConnection();
			sql = "select tto.totalorderkey, tto.itemorderkey, tto.ordercard, tto.totalprice, "
					+ "cp.couponprice, totalprice+couponprice orderprice, "
					+ "io.ordername, io.orderphone, io.address, io.addressdetail, io.orderrequest, io.itemorderdate "
					+ "from oneday.totalorder tto "
					+ "left outer join oneday.itemorder io on tto.itemorderkey = io.itemorderkey "
					+ "left outer join oneday.coupon cp on cp.couponkey = tto.couponkey "
					+ "where tto.itemorderkey=? ";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, itemOrderKey);
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				MyItemTotalOrderDetailBean itodBean = new MyItemTotalOrderDetailBean();
				itodBean.setTotalOrderKey(rs.getInt("totalorderkey"));
				itodBean.setItemOrderKey(rs.getInt("itemorderkey"));
				itodBean.setOrderCard(rs.getString("ordercard"));
				itodBean.setTotalPrice(rs.getInt("totalprice"));
				itodBean.setCouponPrice(rs.getInt("couponprice"));
				if (rs.getInt("couponprice") != 0) {
					itodBean.setOrderPrice(rs.getInt("orderprice"));
				} else {
					itodBean.setOrderPrice(rs.getInt("totalprice"));
				}
				itodBean.setOrderName(rs.getString("ordername"));
				itodBean.setOrderPhone(rs.getString("orderphone"));
				itodBean.setAddress(rs.getString("address"));
				itodBean.setAddressDetail(rs.getString("addressdetail"));
				itodBean.setOrderRequest(rs.getString("orderrequest"));
				itodBean.setItemOrderDate(rs.getString("itemorderdate"));
				vlist.addElement(itodBean);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt, rs);
		}
		return vlist;
	}
	//내 구매 상품 상세 목록
	public Vector<ItemOrderDetailBean> itemOrderDetailList(int itemOrderKey){
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		Vector<ItemOrderDetailBean> vlist = new Vector<ItemOrderDetailBean>();
		try {
			con = pool.getConnection();
			sql = "select iod.itemorderdetailkey, iod.itemkey, iod.itemorderstate, iod.itemoption, iod.itemcount, iod.itemprice, "
					+ "i.itemimg, i.itemname "
					+ "from oneday.itemorderdetail iod "
					+ "left outer join oneday.item i on iod.itemkey = i.itemkey "
					+ "where iod.orderkey=? ";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, itemOrderKey);
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				ItemOrderDetailBean iodBean = new ItemOrderDetailBean();
				iodBean.setItemOrderDetailKey(rs.getInt("itemorderdetailkey"));
				iodBean.setItemKey(rs.getInt("itemkey"));
				iodBean.setItemOrderState(rs.getString("itemorderstate"));
				iodBean.setItemCount(rs.getInt("itemcount"));
				iodBean.setItemPrice(rs.getInt("itemprice"));
				iodBean.setOrderItemImg(rs.getString("itemimg"));
				iodBean.setOrderItemName(rs.getString("itemname"));
				String option = rs.getString("itemoption");
				String os[] = new String[option.length()];
				for (int i = 0; i < os.length; i++) {
					os[i] = option.substring(i, i + 1);
				}
				iodBean.setOrderItemOption(os);
				vlist.addElement(iodBean);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt, rs);
		}
		return vlist;
	}
	//총 주문상품 개수 목록
	public Vector<ItemOrderDetailBean> itemOrderCount(int itemOrderKey){
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		Vector<ItemOrderDetailBean> vlist = new Vector<ItemOrderDetailBean>();
		try {
			con = pool.getConnection();
			sql = "select count(itemcount) totalcount from oneday.itemorderdetail where orderkey=? ";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, itemOrderKey);
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				ItemOrderDetailBean iodBean = new ItemOrderDetailBean();
				iodBean.setTotalItemCount(rs.getInt(1));
				vlist.addElement(iodBean);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt, rs);
		}
		return vlist;
	}
}
