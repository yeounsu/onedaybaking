package onedaybaking;

public class additemBean {
    private int itemkey;
    private String itemname;
    private String itemdate;
    private int itemprice;
    private String itemlocation;
    private String itemkeep;
    private String itemperiod;
    private String itemdelete;
    private String itemimg;
    private String itemimg1;
    private String itemimg2;
    private String itemimg3;
    private String itemimg4;
    private String itemcontent;
    private String memberid;
    private int categorykey;
	public int getItemkey() {
		return itemkey;
	}
	public void setItemkey(int itemkey) {
		this.itemkey = itemkey;
	}
	public String getItemname() {
		return itemname;
	}
	public void setItemname(String itemname) {
		this.itemname = itemname;
	}
	public String getItemdate() {
		return itemdate;
	}
	public void setItemdate(String itemdate) {
		this.itemdate = itemdate;
	}
	public int getItemprice() {
		return itemprice;
	}
	public void setItemprice(int itemprice) {
		this.itemprice = itemprice;
	}
	public String getItemlocation() {
		return itemlocation;
	}
	public void setItemlocation(String itemlocation) {
		this.itemlocation = itemlocation;
	}
	public String getItemkeep() {
		return itemkeep;
	}
	public void setItemkeep(String itemkeep) {
		this.itemkeep = itemkeep;
	}
	public String getItemperiod() {
		return itemperiod;
	}
	public void setItemperiod(String itemperiod) {
		this.itemperiod = itemperiod;
	}
	public String getItemdelete() {
		return itemdelete;
	}
	public void setItemdelete(String itemdelete) {
		this.itemdelete = itemdelete;
	}
	public String getItemimg() {
		return itemimg;
	}
	public void setItemimg(String itemimg) {
		this.itemimg = itemimg;
	}
	public String getItemimg1() {
		return itemimg1;
	}
	public void setItemimg1(String itemimg1) {
		this.itemimg1 = itemimg1;
	}
	public String getItemimg2() {
		return itemimg2;
	}
	public void setItemimg2(String itemimg2) {
		this.itemimg2 = itemimg2;
	}
	public String getItemimg3() {
		return itemimg3;
	}
	public void setItemimg3(String itemimg3) {
		this.itemimg3 = itemimg3;
	}
	public String getItemimg4() {
		return itemimg4;
	}
	public void setItemimg4(String itemimg4) {
		this.itemimg4 = itemimg4;
	}
	public String getItemcontent() {
		return itemcontent;
	}
	public void setItemcontent(String itemcontent) {
		this.itemcontent = itemcontent;
	}
	public String getMemberid() {
		return memberid;
	}
	public void setMemberid(String memberid) {
		this.memberid = memberid;
	}
	public int getCategorykey() {
		return categorykey;
	}
	public void setCategorykey(int categorykey) {
		this.categorykey = categorykey;
	}

   }