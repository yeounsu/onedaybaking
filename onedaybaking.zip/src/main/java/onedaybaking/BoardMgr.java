package onedaybaking;

import java.io.File;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.Vector;

import javax.servlet.http.HttpServletRequest;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;

public class BoardMgr {
	DBConnectionMgr pool;
	//업로드 파일 저장 위치
	public static final String SAVEFOLDER="C:/Jsp/onedaybaking/src/main/webapp/img/item/";
	//업로드 파일 인코딩
	public static final String ENCODING="UTF-8";
	public static final int MAXSIZE = 1024 * 1024 * 20; //20MB
	
	public BoardMgr() {
		pool = DBConnectionMgr.getInstance();
	}
	
	//상품 후기 개수
	public int getItemReviewCount(int num) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		int count = 0;
		try {
			con = pool.getConnection();
			sql = "select count(*) from itemboard where commenttype = 2 and itemkey = ?";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, num);
			rs = pstmt.executeQuery();
			if (rs.next()) count = rs.getInt(1);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt, rs);
		}
		return count;
	}
	
	//상품 후기
	public Vector<ItemBoardBean> getItemReview(int num) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		Vector<ItemBoardBean> vlist = new Vector<ItemBoardBean>();
		try {
			con = pool.getConnection();
			sql = "select * from itemboard a "
					+ "left outer join member b on a.memberid = b.memberid "
					+ "where a.commenttype = 2 and a.itemkey = ? order by itemboardkey desc";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, num);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				ItemBoardBean bean = new ItemBoardBean();
				bean.setItemboardkey(rs.getInt(1));
				bean.setCommenttype(rs.getString(2));
				bean.setCommentcontent(rs.getString(3));
				bean.setCommentdate(rs.getString(4));
				bean.setCommentimg1(rs.getString(5));
				bean.setCommentimg2(rs.getString(6));
				bean.setCommentimg3(rs.getString(7));
				bean.setItemkey(rs.getInt(8));
				bean.setMemberid(rs.getString(9));
				bean.setMembernick(rs.getString("membernick"));
				bean.setMemberimg(rs.getString("memberinfoimg"));
				vlist.addElement(bean);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt, rs);
		}
		return vlist;
	}
	
	//상품 후기 삭제
	public boolean delItemReview(int num, String id, int key) {
		Connection con = null;
		PreparedStatement pstmt = null;
		String sql = null;
		boolean flag = false;
		try {
			con = pool.getConnection();
			sql = "delete from itemboard where memberid = ? and itemkey = ? and itemboardkey = ?";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, id);
			pstmt.setInt(2, num);
			pstmt.setInt(3, key);
			if (pstmt.executeUpdate() == 1) flag = true;
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt);
		}
		return flag;
	}

	//상품 문의 개수
	public int getItemInquireCount(int num) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		int count = 0;
		try {
			con = pool.getConnection();
			sql = "select count(*) from itemboard where commenttype = 1 and itemkey = ?";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, num);
			rs = pstmt.executeQuery();
			if (rs.next()) count = rs.getInt(1);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt, rs);
		}
		return count;
	}

	//상품 문의
	public Vector<ItemBoardBean> getItemInquire(int num) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		Vector<ItemBoardBean> vlist = new Vector<ItemBoardBean>();
		try {
			con = pool.getConnection();
			sql = "select * from itemboard a "
					+ "left outer join member b on a.memberid = b.memberid "
					+ "where a.commenttype = 1 and a.itemkey = ? order by itemboardkey desc";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, num);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				ItemBoardBean bean = new ItemBoardBean();
				bean.setItemboardkey(rs.getInt(1));
				bean.setCommenttype(rs.getString(2));
				bean.setCommentcontent(rs.getString(3));
				bean.setCommentdate(rs.getString(4));
				bean.setCommentimg1(rs.getString(5));
				bean.setCommentimg2(rs.getString(6));
				bean.setCommentimg3(rs.getString(7));
				bean.setItemkey(rs.getInt(8));
				bean.setMemberid(rs.getString(9));
				bean.setMembernick(rs.getString("membernick"));
				bean.setMemberimg(rs.getString("memberinfoimg"));
				bean.setBoardkey(rs.getInt(10));
				vlist.addElement(bean);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt, rs);
		}
		return vlist;
	}
	
	//상품 문의 답글
	public ItemBoardBean getItemInquireReply(int num) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		ItemBoardBean bean = new ItemBoardBean();
		try {
			con = pool.getConnection();
			sql = "select * from itemboard a "
					+ "left outer join member b on a.memberid = b.memberid "
					+ "where a.commenttype = 0 and a.boardkey = ?";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, num);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				bean.setItemboardkey(rs.getInt(1));
				bean.setCommenttype(rs.getString(2));
				bean.setCommentcontent(rs.getString(3));
				bean.setCommentdate(rs.getString(4));
				bean.setItemkey(rs.getInt(8));
				bean.setMemberid(rs.getString(9));
				bean.setMembernick(rs.getString("membernick"));
				bean.setMemberimg(rs.getString("memberinfoimg"));
				bean.setBoardkey(rs.getInt(10));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt, rs);
		}
		return bean;
	}
	
	//상품 문의 삭제
	public boolean delItemInquire(String id, int num, int key) {
		Connection con = null;
		PreparedStatement pstmt = null;
		String sql = null;
		boolean flag = false;
		try {
			con = pool.getConnection();
			sql = "delete from itemboard where memberid = ? and itemkey = ? and itemboardkey = ?";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, id);
			pstmt.setInt(2, num);
			pstmt.setInt(3, key);
			if (pstmt.executeUpdate() == 1) {
				flag = true;
				pool.freeConnection(con, pstmt);
				con = pool.getConnection();
				sql = "delete from itemboard where itemkey = ? and boardkey = ?";
				pstmt = con.prepareStatement(sql);
				pstmt.setInt(1, num);
				pstmt.setInt(2, key);
				pstmt.executeUpdate();
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt);
		}
		return flag;
	}
	
	//상품 문의 작성
	public void writeItemInquire(String id, String content, String img1, String img2, String img3, String type, int key, int boardkey) {
		Connection con = null;
		PreparedStatement pstmt = null;
		String sql = null;
		boolean flag = false;
		try {
			con = pool.getConnection();
			sql = "insert into itemboard values (null, ?, ?, now(), ?, ?, ?, ?, ?, ?)";
			pstmt = con.prepareStatement(sql);
			if (type.equals("inquire")) {
				pstmt.setString(1, "1");
				pstmt.setNull(8, Types.NUMERIC);
			} else if (type.equals("reply")) {
				pstmt.setString(1, "0");
				pstmt.setInt(8, boardkey);
			}
			pstmt.setString(2, content);
			if (img1 != null) pstmt.setString(3, img1); else pstmt.setNull(3, Types.VARCHAR);
			if (img2 != null) pstmt.setString(4, img2); else pstmt.setNull(4, Types.VARCHAR);
			if (img3 != null) pstmt.setString(5, img3); else pstmt.setNull(5, Types.VARCHAR);
			pstmt.setInt(6, key);
			pstmt.setString(7, id);
			pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt);
		}
	}
	
	//클래스 후기 개수
	public int getClassReviewCount(int num) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		int count = 0;
		try {
			con = pool.getConnection();
			sql = "select count(*) from classboard where commenttype = 2 and classkey = ?";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, num);
			rs = pstmt.executeQuery();
			if (rs.next()) count = rs.getInt(1);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt, rs);
		}
		return count;
	}
		
	//클래스 후기
	public Vector<ClassBoardBean> getClassReview(int num) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		Vector<ClassBoardBean> vlist = new Vector<ClassBoardBean>();
		try {
			con = pool.getConnection();
			sql = "select * from classboard a "
					+ "left outer join member b on a.memberid = b.memberid "
					+ "where a.commenttype = 2 and a.classkey = ? order by classboardkey desc";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, num);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				ClassBoardBean bean = new ClassBoardBean();
				bean.setClassboardkey(rs.getInt(1));
				bean.setCommenttype(rs.getString(2));
				bean.setCommentcontent(rs.getString(3));
				bean.setCommentdate(rs.getString(4));
				bean.setCommentimg1(rs.getString(5));
				bean.setCommentimg2(rs.getString(6));
				bean.setCommentimg3(rs.getString(7));
				bean.setClasskey(rs.getInt(8));
				bean.setMemberid(rs.getString(9));
				bean.setMembernick(rs.getString("membernick"));
				bean.setMemberimg(rs.getString("memberinfoimg"));
				vlist.addElement(bean);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt, rs);
		}
		return vlist;
	}
	
	//클래스 후기 삭제
	public boolean delClassReview(int num, String id, int key) {
		Connection con = null;
		PreparedStatement pstmt = null;
		String sql = null;
		boolean flag = false;
		try {
			con = pool.getConnection();
			sql = "delete from classboard where memberid = ? and classkey = ? and classboardkey = ?";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, id);
			pstmt.setInt(2, num);
			pstmt.setInt(3, key);
			if (pstmt.executeUpdate() == 1) flag = true;
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt);
		}
		return flag;
	}

	//클래스 문의 개수
	public int getClassInquireCount(int num) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		int count = 0;
		try {
			con = pool.getConnection();
			sql = "select count(*) from classboard where commenttype = 1 and classkey = ?";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, num);
			rs = pstmt.executeQuery();
			if (rs.next()) count = rs.getInt(1);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt, rs);
		}
		return count;
	}

	//상품 문의
	public Vector<ClassBoardBean> getClassInquire(int num) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		Vector<ClassBoardBean> vlist = new Vector<ClassBoardBean>();
		try {
			con = pool.getConnection();
			sql = "select * from classboard a "
					+ "left outer join member b on a.memberid = b.memberid "
					+ "where a.commenttype = 1 and a.classkey = ? order by classboardkey desc";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, num);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				ClassBoardBean bean = new ClassBoardBean();
				bean.setClassboardkey(rs.getInt(1));
				bean.setCommenttype(rs.getString(2));
				bean.setCommentcontent(rs.getString(3));
				bean.setCommentdate(rs.getString(4));
				bean.setCommentimg1(rs.getString(5));
				bean.setCommentimg2(rs.getString(6));
				bean.setCommentimg3(rs.getString(7));
				bean.setClasskey(rs.getInt(8));
				bean.setMemberid(rs.getString(9));
				bean.setMembernick(rs.getString("membernick"));
				bean.setMemberimg(rs.getString("memberinfoimg"));
				bean.setBoardkey(rs.getInt(10));
				vlist.addElement(bean);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt, rs);
		}
		return vlist;
	}
	
	//상품 문의 답글
	public ClassBoardBean getClassInquireReply(int num) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		ClassBoardBean bean = new ClassBoardBean();
		try {
			con = pool.getConnection();
			sql = "select * from classboard a "
					+ "left outer join member b on a.memberid = b.memberid "
					+ "where a.commenttype = 0 and a.boardkey = ?";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, num);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				bean.setClassboardkey(rs.getInt(1));
				bean.setCommenttype(rs.getString(2));
				bean.setCommentcontent(rs.getString(3));
				bean.setCommentdate(rs.getString(4));
				bean.setClasskey(rs.getInt(8));
				bean.setMemberid(rs.getString(9));
				bean.setMembernick(rs.getString("membernick"));
				bean.setMemberimg(rs.getString("memberinfoimg"));
				bean.setBoardkey(rs.getInt(10));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt, rs);
		}
		return bean;
	}
	
	//상품 문의 삭제
	public boolean delClassInquire(String id, int num, int key) {
		Connection con = null;
		PreparedStatement pstmt = null;
		String sql = null;
		boolean flag = false;
		try {
			con = pool.getConnection();
			sql = "delete from classboard where memberid = ? and classkey = ? and classboardkey = ?";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, id);
			pstmt.setInt(2, num);
			pstmt.setInt(3, key);
			if (pstmt.executeUpdate() == 1) {
				flag = true;
				pool.freeConnection(con, pstmt);
				con = pool.getConnection();
				sql = "delete from classboard where classkey = ? and boardkey = ?";
				pstmt = con.prepareStatement(sql);
				pstmt.setInt(1, num);
				pstmt.setInt(2, key);
				pstmt.executeUpdate();
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt);
		}
		return flag;
	}
	
	//상품 문의 작성
	public void writeClassInquire(String id, String content, String img1, String img2, String img3, String type, int key, int boardkey) {
		Connection con = null;
		PreparedStatement pstmt = null;
		String sql = null;
		boolean flag = false;
		try {
			con = pool.getConnection();
			sql = "insert into classboard values (null, ?, ?, now(), ?, ?, ?, ?, ?, ?)";
			pstmt = con.prepareStatement(sql);
			if (type.equals("inquire")) {
				pstmt.setString(1, "1");
				pstmt.setNull(8, Types.NUMERIC);
			} else if (type.equals("reply")) {
				pstmt.setString(1, "0");
				pstmt.setInt(8, boardkey);
			}
			pstmt.setString(2, content);
			if (img1 != null) pstmt.setString(3, img1); else pstmt.setNull(3, Types.VARCHAR);
			if (img2 != null) pstmt.setString(4, img2); else pstmt.setNull(4, Types.VARCHAR);
			if (img3 != null) pstmt.setString(5, img3); else pstmt.setNull(5, Types.VARCHAR);
			pstmt.setInt(6, key);
			pstmt.setString(7, id);
			pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt);
		}
	}
	//주문 상품 후기 작성
	public boolean orderItemReview(HttpServletRequest req, String memberId) {
		Connection con = null;
		PreparedStatement pstmt = null;
		String sql = null;
		boolean flag = false;
		try {
			con = pool.getConnection();
			File dir = new File(SAVEFOLDER);
			if (!dir.exists())
				dir.mkdirs();
			MultipartRequest multi = new MultipartRequest(req,SAVEFOLDER, MAXSIZE, ENCODING, new DefaultFileRenamePolicy());
			String reviewImg = multi.getFilesystemName("commentimg1");
			String reviewContent = multi.getParameter("commentcontent");
			sql = "insert into itemboard values(null, null,?,?,now(),?,null,null,?,?)";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, "2");
			pstmt.setString(2, reviewContent);
			pstmt.setString(3, reviewImg);
			pstmt.setInt(4,Integer.parseInt(multi.getParameter("itemKey")));
			pstmt.setString(5, memberId);

			if(pstmt.executeUpdate() == 1) flag = true;
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt);
		}
		return flag;
	}
}