package onedaybaking;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;

import javax.servlet.http.HttpServletRequest;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;


public class getItemMgr {
	DBConnectionMgr pool;
	
	public getItemMgr() {
		pool = DBConnectionMgr.getInstance();
	}
	
	//클래스 신청 갯수 (개인)
	public int getapplicationitem(String id) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		int count = 0;
		try {
			con = pool.getConnection();
			sql = "select count(*) from item where memberid = ?";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, id);
			rs = pstmt.executeQuery();
			if (rs.next()) count = rs.getInt(1);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt, rs);
		}
		return count;
	}
	public Vector<ItemBean> getWishItemList(String id) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		Vector<ItemBean> vlist = new Vector<ItemBean>();
		try {
			con = pool.getConnection();
			sql = "select * from item a "
					+ "left outer join item b on a.itemkey = b.itemkey "
					+ "left outer join member c on b.memberid = c.memberid "
					+ "where a.memberId = ? order by a.itemkey desc";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, id);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				ItemBean bean = new ItemBean();
				bean.setItemkey(rs.getInt("itemkey"));
				bean.setItemimg(rs.getString("itemimg"));
				bean.setItemname(rs.getString("itemname"));
				bean.setItemprice(rs.getInt("itemprice"));
				vlist.addElement(bean);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt, rs);
		}
		return vlist;
	}

	public boolean deleteItem(int itemkey) {
        Connection con = null;
        PreparedStatement pstmtCategory = null;
        PreparedStatement pstmtClass = null;
        boolean flag = false;
        
        try {
            con = pool.getConnection();
            con.setAutoCommit(false); // 자동 커밋 비활성화
            
            // 클래스 테이블에서 클래스의 categorykey 가져오기
            int categoryKey = 0;
            String sqlSelectCategoryKey = "SELECT categorykey FROM item WHERE itemkey = ?";
            pstmtCategory = con.prepareStatement(sqlSelectCategoryKey);
            pstmtCategory.setInt(1, itemkey);
            ResultSet rs = pstmtCategory.executeQuery();
            if (rs.next()) {
                categoryKey = rs.getInt("categorykey");
            }
            rs.close();

            // 클래스와 관련된 카테고리 테이블의 데이터 삭제
            String sqlDeleteCategory = "DELETE FROM category WHERE categorykey = ?";
            pstmtCategory = con.prepareStatement(sqlDeleteCategory);
            pstmtCategory.setInt(1, categoryKey);
            pstmtCategory.executeUpdate();
            
            String sqlDeleteOption = "DELETE FROM itemoption WHERE itemkey = ?";
            pstmtClass = con.prepareStatement(sqlDeleteOption);
            pstmtClass.setInt(1, itemkey);
            pstmtClass.executeUpdate();


            // 클래스 테이블에서 클래스 삭제
            String sqlDeleteClass = "DELETE FROM item WHERE itemkey = ?";
            pstmtClass = con.prepareStatement(sqlDeleteClass);
            pstmtClass.setInt(1, itemkey);
            if (pstmtClass.executeUpdate() == 1) {
                flag = true;
                con.commit(); // 커밋
            } else {
                con.rollback(); // 롤백
            }
        } catch (Exception e) {
            e.printStackTrace();
            if (con != null) {
                try {
                    con.rollback(); // 예외 발생 시 롤백
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        } finally {
            // 자원 반환
            if (pstmtCategory != null) {
                try {
                    pstmtCategory.close();
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
            if (pstmtClass != null) {
                try {
                    pstmtClass.close();
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
            if (con != null) {
                try {
                    con.setAutoCommit(true); // 다시 자동 커밋 활성화
                    pool.freeConnection(con);
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        }
        return flag;
	}
	
	public ItemBean getIteminfoByItemkey(int itemkey) {
	    Connection con = null;
	    PreparedStatement pstmt = null;
	    ResultSet rs = null;
	    String sql = null;
	    ItemBean bean = new ItemBean();

	    try {
	        con = pool.getConnection();
	        sql = "SELECT * "
	        		+ "FROM item c "
	        		+ "INNER JOIN category cat ON c.categorykey = cat.categorykey "
	        		+ "INNER JOIN itemoption o ON c.itemkey = o.itemkey "
	        		+ "WHERE c.itemkey = ?";
	        pstmt = con.prepareStatement(sql);
	        pstmt.setInt(1, itemkey);
	        rs = pstmt.executeQuery();

	        if (rs.next()) {
	            // Set item fields
	            bean.setItemkey(rs.getInt("itemkey"));
	            bean.setItemname(rs.getString("itemname"));
	            bean.setItemdate(rs.getString("itemdate"));
	            bean.setItemprice(rs.getInt("itemprice"));
	            bean.setItemlocation(rs.getString("itemlocation"));
	            bean.setItemkeep(rs.getString("itemkeep"));
	            bean.setItemperiod(rs.getString("itemperiod"));
	            bean.setItemdelete(rs.getString("itemdelete"));
	            bean.setItemimg(rs.getString("itemimg"));
	            bean.setItemimg1(rs.getString("itemimg1"));
	            bean.setItemimg2(rs.getString("itemimg2"));
	            bean.setItemimg3(rs.getString("itemimg3"));
	            bean.setItemimg4(rs.getString("itemimg4"));
	            bean.setItemcontent(rs.getString("itemcontent"));
	            bean.setMemberid(rs.getString("memberid"));
	            bean.setCategorykey(rs.getInt("categorykey"));

	            // Set category fields
	            categoryBean categoryBean = new categoryBean();
	            categoryBean.setCategorykey(rs.getInt("categorykey"));
	            categoryBean.setCategorygroup(rs.getString("categorygroup"));
	            categoryBean.setCategoryname(rs.getString("categoryname"));
	            bean.setCate(categoryBean);
	            bean.setCategorykey(itemkey);

	            // Set option fields
	            OptionBean optionBean = new OptionBean();
	            optionBean.setOptionkey(rs.getInt("optionkey"));
	            optionBean.setItemoption1(rs.getString("itemoption1"));
	            optionBean.setItemoption2(rs.getString("itemoption2"));
	            optionBean.setItemoption3(rs.getString("itemoption3"));
	            optionBean.setItemoption4(rs.getString("itemoption4"));
	            optionBean.setItemoption5(rs.getString("itemoption5"));
	            optionBean.setItemoption6(rs.getString("itemoption6"));
	            optionBean.setItemoption7(rs.getString("itemoption7"));
	            optionBean.setItemoption8(rs.getString("itemoption8"));
	            optionBean.setItemoption9(rs.getString("itemoption9"));
	            optionBean.setItemoption10(rs.getString("itemoption10"));
	            optionBean.setItemsoption1(rs.getString("itemsoption1"));
	            optionBean.setItemsoption2(rs.getString("itemsoption2"));
	            optionBean.setItemsoption3(rs.getString("itemsoption3"));
	            optionBean.setItemsoption4(rs.getString("itemsoption4"));
	            optionBean.setItemsoption5(rs.getString("itemsoption5"));
	            optionBean.setItemsoption6(rs.getString("itemsoption6"));
	            optionBean.setItemsoption7(rs.getString("itemsoption7"));
	            optionBean.setItemsoption8(rs.getString("itemsoption8"));
	            optionBean.setItemsoption9(rs.getString("itemsoption9"));
	            optionBean.setItemsoption10(rs.getString("itemsoption10"));
	            optionBean.setItemkey(rs.getInt("itemkey"));
	            
	            bean.setOption(optionBean);
	        }
	    } catch (Exception e) {
	        e.printStackTrace();
	    } finally {
	        pool.freeConnection(con, pstmt, rs);
	    }

	    return bean;
	}
	 
	 
}

