package onedaybaking;

public class MyInquireItemBean {
	private int itemBoardKey;
	private String memberInfoImg;
	private int itemKey;
	private String name;
	private String commentContent;
	private String commentDate;
	private String commentimg1;
	private String commentimg2;
	private String commentimg3;
	private String replyComment;
	private String replyNick;
	private String replyDate;
	
	public int getItemBoardKey() {
		return itemBoardKey;
	}
	public void setItemBoardKey(int itemBoardKey) {
		this.itemBoardKey = itemBoardKey;
	}
	public String getMemberInfoImg() {
		return memberInfoImg;
	}
	public void setMemberInfoImg(String memberInfoImg) {
		this.memberInfoImg = memberInfoImg;
	}
	public int getItemKey() {
		return itemKey;
	}
	public void setItemKey(int itemKey) {
		this.itemKey = itemKey;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCommentContent() {
		return commentContent;
	}
	public void setCommentContent(String commentContent) {
		this.commentContent = commentContent;
	}
	public String getCommentDate() {
		return commentDate;
	}
	public void setCommentDate(String commentDate) {
		this.commentDate = commentDate;
	}
	public String getCommentimg1() {
		return commentimg1;
	}
	public void setCommentimg1(String commentimg1) {
		this.commentimg1 = commentimg1;
	}
	public String getCommentimg2() {
		return commentimg2;
	}
	public void setCommentimg2(String commentimg2) {
		this.commentimg2 = commentimg2;
	}
	public String getCommentimg3() {
		return commentimg3;
	}
	public void setCommentimg3(String commentimg3) {
		this.commentimg3 = commentimg3;
	}
	public String getReplyComment() {
		return replyComment;
	}
	public void setReplyComment(String replyComment) {
		this.replyComment = replyComment;
	}
	public String getReplyNick() {
		return replyNick;
	}
	public void setReplyNick(String replyNick) {
		this.replyNick = replyNick;
	}
	public String getReplyDate() {
		return replyDate;
	}
	public void setReplyDate(String replyDate) {
		this.replyDate = replyDate;
	}
	
}
