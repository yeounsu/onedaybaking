package onedaybaking;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Vector;

public class CouponMgr {
	DBConnectionMgr pool;
	
	public CouponMgr() {
		pool = DBConnectionMgr.getInstance();
	}
	
	//쿠폰 리스트
	public Vector<CouponBean> couponList(String memberId) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		Vector<CouponBean> vlist = new Vector<CouponBean>();
		try {
			con = pool.getConnection();
			sql = "select * from coupon where memberId=? and couponStatus='N' and date_format(now(), '%Y-%m-%d') BETWEEN coupondown AND couponclose order by couponKey desc";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, memberId);

			rs = pstmt.executeQuery();
			while(rs.next()) {
				CouponBean cpBean = new CouponBean();
				cpBean.setCouponKey(rs.getInt(1));
				cpBean.setCouponName(rs.getString(2));
				cpBean.setCouponPrice(rs.getInt(3));
				cpBean.setCouponDown(rs.getString(4));
				cpBean.setCouponClose(rs.getString(5));
				cpBean.setCouponStatus(rs.getString(6));
				cpBean.setMemberId(rs.getString(7));
				vlist.addElement(cpBean);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt, rs);
		}
		return vlist;
	}
	
	//전체 쿠폰 발급
	public boolean allCoupon(String cname, int cprice, String sdate, String edate) {
		Connection con = null;
		PreparedStatement pstmt = null;
		String sql = null;
		boolean flag = false;
		try {
			MemberMgr2 mgr = new MemberMgr2();
			Vector<String> vlist = mgr.getAllMembers();
			for (int i = 0; i < vlist.size(); i++) {
					con = pool.getConnection();
					sql = "insert into coupon values (null, ?, ?, ?, ?, 'N', ?)";
					pstmt = con.prepareStatement(sql);
					pstmt.setString(1, cname);
					pstmt.setInt(2, cprice);
					pstmt.setString(3, sdate);
					pstmt.setString(4, edate);
					pstmt.setString(5, vlist.get(i));
					pstmt.executeUpdate();
					pool.freeConnection(con, pstmt);
			}
			con = pool.getConnection();
			sql = "insert into coupon values (null, ?, ?, ?, ?, 'N', ?)";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, cname);
			pstmt.setInt(2, cprice);
			pstmt.setString(3, sdate);
			pstmt.setString(4, edate);
			pstmt.setString(5, "admin");
			if (pstmt.executeUpdate() == 1) flag = true;
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt);
		}
		return flag;
	}
	
	//전체 발급 쿠폰 목록 (id : admin)
	public Vector<CouponBean> getAllCoupons() {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		Vector<CouponBean> vlist = new Vector<CouponBean>();
		try {
			con = pool.getConnection();
			sql = "select * from coupon where memberid = 'admin' order by couponkey desc";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				CouponBean bean = new CouponBean();
				bean.setCouponName(rs.getString("couponname"));
				bean.setCouponPrice(rs.getInt("couponprice"));
				bean.setCouponDown(rs.getString("coupondown"));
				bean.setCouponClose(rs.getString("couponclose"));
				vlist.addElement(bean);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt, rs);
		}
		return vlist;
	}
}