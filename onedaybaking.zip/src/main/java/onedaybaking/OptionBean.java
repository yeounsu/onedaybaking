package onedaybaking;

public class OptionBean {
	private int optionkey;
	private String itemoption1;
	private String itemoption2;
	private String itemoption3;
	private String itemoption4;
	private String itemoption5;
	private String itemoption6;
	private String itemoption7;
	private String itemoption8;
	private String itemoption9;
	private String itemoption10;
	private String itemsoption1;
	private String itemsoption2;
	private String itemsoption3;
	private String itemsoption4;
	private String itemsoption5;
	private String itemsoption6;
	private String itemsoption7;
	private String itemsoption8;
	private String itemsoption9;
	private String itemsoption10;
	private int itemkey;
	public int getItemkey() {
		return itemkey;
	}
	public void setItemkey(int itemkey) {
		this.itemkey = itemkey;
	}
	public int getOptionkey() {
		return optionkey;
	}
	public void setOptionkey(int optionkey) {
		this.optionkey = optionkey;
	}
	public String getItemoption1() {
		return itemoption1;
	}
	public void setItemoption1(String itemoption1) {
		this.itemoption1 = itemoption1;
	}
	public String getItemoption2() {
		return itemoption2;
	}
	public void setItemoption2(String itemoption2) {
		this.itemoption2 = itemoption2;
	}
	public String getItemoption3() {
		return itemoption3;
	}
	public void setItemoption3(String itemoption3) {
		this.itemoption3 = itemoption3;
	}
	public String getItemoption4() {
		return itemoption4;
	}
	public void setItemoption4(String itemoption4) {
		this.itemoption4 = itemoption4;
	}
	public String getItemoption5() {
		return itemoption5;
	}
	public void setItemoption5(String itemoption5) {
		this.itemoption5 = itemoption5;
	}
	public String getItemoption6() {
		return itemoption6;
	}
	public void setItemoption6(String itemoption6) {
		this.itemoption6 = itemoption6;
	}
	public String getItemoption7() {
		return itemoption7;
	}
	public void setItemoption7(String itemoption7) {
		this.itemoption7 = itemoption7;
	}
	public String getItemoption8() {
		return itemoption8;
	}
	public void setItemoption8(String itemoption8) {
		this.itemoption8 = itemoption8;
	}
	public String getItemoption9() {
		return itemoption9;
	}
	public void setItemoption9(String itemoption9) {
		this.itemoption9 = itemoption9;
	}
	public String getItemoption10() {
		return itemoption10;
	}
	public void setItemoption10(String itemoption10) {
		this.itemoption10 = itemoption10;
	}
	public String getItemsoption1() {
		return itemsoption1;
	}
	public void setItemsoption1(String itemsoption1) {
		this.itemsoption1 = itemsoption1;
	}
	public String getItemsoption2() {
		return itemsoption2;
	}
	public void setItemsoption2(String itemsoption2) {
		this.itemsoption2 = itemsoption2;
	}
	public String getItemsoption3() {
		return itemsoption3;
	}
	public void setItemsoption3(String itemsoption3) {
		this.itemsoption3 = itemsoption3;
	}
	public String getItemsoption4() {
		return itemsoption4;
	}
	public void setItemsoption4(String itemsoption4) {
		this.itemsoption4 = itemsoption4;
	}
	public String getItemsoption5() {
		return itemsoption5;
	}
	public void setItemsoption5(String itemsoption5) {
		this.itemsoption5 = itemsoption5;
	}
	public String getItemsoption6() {
		return itemsoption6;
	}
	public void setItemsoption6(String itemsoption6) {
		this.itemsoption6 = itemsoption6;
	}
	public String getItemsoption7() {
		return itemsoption7;
	}
	public void setItemsoption7(String itemsoption7) {
		this.itemsoption7 = itemsoption7;
	}
	public String getItemsoption8() {
		return itemsoption8;
	}
	public void setItemsoption8(String itemsoption8) {
		this.itemsoption8 = itemsoption8;
	}
	public String getItemsoption9() {
		return itemsoption9;
	}
	public void setItemsoption9(String itemsoption9) {
		this.itemsoption9 = itemsoption9;
	}
	public String getItemsoption10() {
		return itemsoption10;
	}
	public void setItemsoption10(String itemsoption10) {
		this.itemsoption10 = itemsoption10;
	}
}
