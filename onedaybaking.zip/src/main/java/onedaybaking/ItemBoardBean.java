package onedaybaking;

public class ItemBoardBean {
	
	private int itemboardkey;
	private String commenttype;
	private String commentcontent;
	private String commentdate;
	private String commentimg1;
	private String commentimg2;
	private String commentimg3;
	private int itemkey;
	private String memberid;
	private String membernick;
	private String memberimg;
	private int boardkey;
	
	public int getItemboardkey() {
		return itemboardkey;
	}
	public void setItemboardkey(int itemboardkey) {
		this.itemboardkey = itemboardkey;
	}
	public String getCommenttype() {
		return commenttype;
	}
	public void setCommenttype(String commenttype) {
		this.commenttype = commenttype;
	}
	public String getCommentcontent() {
		return commentcontent;
	}
	public void setCommentcontent(String commentcontent) {
		this.commentcontent = commentcontent;
	}
	public String getCommentdate() {
		return commentdate;
	}
	public void setCommentdate(String commentdate) {
		this.commentdate = commentdate;
	}
	public String getCommentimg1() {
		return commentimg1;
	}
	public void setCommentimg1(String commentimg1) {
		this.commentimg1 = commentimg1;
	}
	public String getCommentimg2() {
		return commentimg2;
	}
	public void setCommentimg2(String commentimg2) {
		this.commentimg2 = commentimg2;
	}
	public String getCommentimg3() {
		return commentimg3;
	}
	public void setCommentimg3(String commentimg3) {
		this.commentimg3 = commentimg3;
	}
	public int getItemkey() {
		return itemkey;
	}
	public void setItemkey(int itemkey) {
		this.itemkey = itemkey;
	}
	public String getMemberid() {
		return memberid;
	}
	public void setMemberid(String memberid) {
		this.memberid = memberid;
	}
	public String getMembernick() {
		return membernick;
	}
	public void setMembernick(String membernick) {
		this.membernick = membernick;
	}
	public String getMemberimg() {
		return memberimg;
	}
	public void setMemberimg(String memberimg) {
		this.memberimg = memberimg;
	}
	public int getBoardkey() {
		return boardkey;
	}
	public void setBoardkey(int boardkey) {
		this.boardkey = boardkey;
	}
}