package onedaybaking;

public class ClassBean {
	
	private int classkey;
	private String classname;
	private String classdate;
	private int classmin;
	private int classmax;
	private int classprice;
	private String classlevel;
	private int classtime;
	private String address;
	private String addressdetail;
	private String offercontent;
	private String[] classstatus;
	private String classdelete;
	private String classteacherinfo;
	private String classteacherimg;
	private String classimg1;
	private String classimg2;
	private String classimg3;
	private String classimg4;
	private String classimg5;
	private String classcontent;
	private String roomimg1;
	private String roomimg2;
	private String memberid;
	private int categorykey;
	private String membername;
	private String classteachername;
	private String memberimg;
	public String getMemberimg() {
		return memberimg;
	}
	public void setMemberimg(String memberimg) {
		this.memberimg = memberimg;
	}
	private categoryBean categoryBean;
	public categoryBean getCategoryBean() {
		return categoryBean;
	}
	public void setCategoryBean(categoryBean categoryBean) {
		this.categoryBean = categoryBean;
	}
	public int getClasskey() {
		return classkey;
	}
	public void setClasskey(int classkey) {
		this.classkey = classkey;
	}
	public String getClassname() {
		return classname;
	}
	public void setClassname(String classname) {
		this.classname = classname;
	}
	public String getClassdate() {
		return classdate;
	}
	public void setClassdate(String classdate) {
		this.classdate = classdate;
	}
	public int getClassmin() {
		return classmin;
	}
	public void setClassmin(int classmin) {
		this.classmin = classmin;
	}
	public int getClassmax() {
		return classmax;
	}
	public void setClassmax(int classmax) {
		this.classmax = classmax;
	}
	public int getClassprice() {
		return classprice;
	}
	public void setClassprice(int classprice) {
		this.classprice = classprice;
	}
	public String getClasslevel() {
		return classlevel;
	}
	public void setClasslevel(String classlevel) {
		this.classlevel = classlevel;
	}
	public int getClasstime() {
		return classtime;
	}
	public void setClasstime(int classtime) {
		this.classtime = classtime;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getAddressdetail() {
		return addressdetail;
	}
	public void setAddressdetail(String addressdetail) {
		this.addressdetail = addressdetail;
	}
	public String getOffercontent() {
		return offercontent;
	}
	public void setOffercontent(String offercontent) {
		this.offercontent = offercontent;
	}
	public String[] getClassstatus() {
		return classstatus;
	}
	public void setClassstatus(String[] classstatus) {
		this.classstatus = classstatus;
	}
	public String getClassdelete() {
		return classdelete;
	}
	public void setClassdelete(String classdelete) {
		this.classdelete = classdelete;
	}
	public String getClassteacherinfo() {
		return classteacherinfo;
	}
	public void setClassteacherinfo(String classteacherinfo) {
		this.classteacherinfo = classteacherinfo;
	}
	public String getClassteacherimg() {
		return classteacherimg;
	}
	public void setClassteacherimg(String classteacherimg) {
		this.classteacherimg = classteacherimg;
	}
	public String getClassimg1() {
		return classimg1;
	}
	public void setClassimg1(String classimg1) {
		this.classimg1 = classimg1;
	}
	public String getClassimg2() {
		return classimg2;
	}
	public void setClassimg2(String classimg2) {
		this.classimg2 = classimg2;
	}
	public String getClassimg3() {
		return classimg3;
	}
	public void setClassimg3(String classimg3) {
		this.classimg3 = classimg3;
	}
	public String getClassimg4() {
		return classimg4;
	}
	public void setClassimg4(String classimg4) {
		this.classimg4 = classimg4;
	}
	public String getClassimg5() {
		return classimg5;
	}
	public void setClassimg5(String classimg5) {
		this.classimg5 = classimg5;
	}
	public String getClasscontent() {
		return classcontent;
	}
	public void setClasscontent(String classcontent) {
		this.classcontent = classcontent;
	}
	public String getRoomimg1() {
		return roomimg1;
	}
	public void setRoomimg1(String roomimg1) {
		this.roomimg1 = roomimg1;
	}
	public String getRoomimg2() {
		return roomimg2;
	}
	public void setRoomimg2(String roomimg2) {
		this.roomimg2 = roomimg2;
	}
	public String getMemberid() {
		return memberid;
	}
	public void setMemberid(String memberid) {
		this.memberid = memberid;
	}
	public int getCategorykey() {
		return categorykey;
	}
	public void setCategorykey(int categorykey) {
		this.categorykey = categorykey;
	}
	public String getMembername() {
		return membername;
	}
	public void setMembername(String membername) {
		this.membername = membername;
	}
	public String getClassteachername() {
		return classteachername;
	}
	public void setClassteachername(String classteachername) {
		this.classteachername = classteachername;
	}
	
	
}