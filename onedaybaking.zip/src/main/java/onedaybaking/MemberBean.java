package onedaybaking;

public class MemberBean {
	private String memberId;
	private String memberPwd;
	private String salt;
	private String memberName;
	private String memberBirth;
	private String memberSex;
	private String memberNick;
	private String memberPhone;
	private String signout;
	private int auth;
	private String memberInfoImg;
	private String memberInfo;
	private String memberdate;
	
	public String getMemberId() {
		return memberId;
	}
	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}
	public String getMemberPwd() {
		return memberPwd;
	}
	public void setMemberPwd(String memberPwd) {
		this.memberPwd = memberPwd;
	}
	public String getSalt() {
		return salt;
	}
	public void setSalt(String salt) {
		this.salt = salt;
	}
	public String getMemberName() {
		return memberName;
	}
	public void setMemberName(String memberName) {
		this.memberName = memberName;
	}
	public String getMemberBirth() {
		return memberBirth;
	}
	public void setMemberBirth(String memberBirth) {
		this.memberBirth = memberBirth;
	}
	public String getMemberSex() {
		return memberSex;
	}
	public void setMemberSex(String memberSex) {
		this.memberSex = memberSex;
	}
	public String getMemberNick() {
		return memberNick;
	}
	public void setMemberNick(String memberNick) {
		this.memberNick = memberNick;
	}
	public String getMemberPhone() {
		return memberPhone;
	}
	public void setMemberPhone(String memberPhone) {
		this.memberPhone = memberPhone;
	}
	public String getSignout() {
		return signout;
	}
	public void setSignout(String signout) {
		this.signout = signout;
	}
	public int getAuth() {
		return auth;
	}
	public void setAuth(int auth) {
		this.auth = auth;
	}
	public String getMemberInfoImg() {
		return memberInfoImg;
	}
	public void setMemberInfoImg(String memberInfoImg) {
		this.memberInfoImg = memberInfoImg;
	}
	public String getMemberInfo() {
		return memberInfo;
	}
	public void setMemberInfo(String memberInfo) {
		this.memberInfo = memberInfo;
	}
	public String getMemberdate() {
		return memberdate;
	}
	public void setMemberdate(String memberdate) {
		this.memberdate = memberdate;
	}
	
	
}
