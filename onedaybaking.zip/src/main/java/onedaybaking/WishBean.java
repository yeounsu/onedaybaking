package onedaybaking;

public class WishBean {
	
	private int wishkey;
	private String memberid;
	private int classkey;
	private int itemkey;
	
	public int getWishkey() {
		return wishkey;
	}
	public void setWishkey(int wishkey) {
		this.wishkey = wishkey;
	}
	public String getMemberid() {
		return memberid;
	}
	public void setMemberid(String memberid) {
		this.memberid = memberid;
	}
	public int getClasskey() {
		return classkey;
	}
	public void setClasskey(int classkey) {
		this.classkey = classkey;
	}
	public int getItemkey() {
		return itemkey;
	}
	public void setItemkey(int itemkey) {
		this.itemkey = itemkey;
	}
}