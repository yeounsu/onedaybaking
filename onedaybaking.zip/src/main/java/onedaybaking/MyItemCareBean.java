package onedaybaking;

public class MyItemCareBean {
	private int totalOrderKey;
	private String orderdate;
	private String orderMemberId;
	private String orderItemName;
	private int itemKey;
	private String orderName;
	private String orderPhone;
	private int itemCount;
	private String itemOption[];
	private String itemOrderState;
	private int itemOrderDetailKey;
	
	
	public int getTotalOrderKey() {
		return totalOrderKey;
	}
	public void setTotalOrderKey(int totalOrderKey) {
		this.totalOrderKey = totalOrderKey;
	}
	public String getOrderdate() {
		return orderdate;
	}
	public void setOrderdate(String orderdate) {
		this.orderdate = orderdate;
	}
	public String getOrderMemberId() {
		return orderMemberId;
	}
	public void setOrderMemberId(String orderMemberId) {
		this.orderMemberId = orderMemberId;
	}
	public String getOrderItemName() {
		return orderItemName;
	}
	public void setOrderItemName(String orderItemName) {
		this.orderItemName = orderItemName;
	}
	public int getItemKey() {
		return itemKey;
	}
	public void setItemKey(int itemKey) {
		this.itemKey = itemKey;
	}
	public String getOrderName() {
		return orderName;
	}
	public void setOrderName(String orderName) {
		this.orderName = orderName;
	}
	public String getOrderPhone() {
		return orderPhone;
	}
	public void setOrderPhone(String orderPhone) {
		this.orderPhone = orderPhone;
	}
	public int getItemCount() {
		return itemCount;
	}
	public void setItemCount(int itemCount) {
		this.itemCount = itemCount;
	}
	
	public String[] getItemOption() {
		return itemOption;
	}
	public void setItemOption(String[] itemOption) {
		this.itemOption = itemOption;
	}
	public String getItemOrderState() {
		return itemOrderState;
	}
	public void setItemOrderState(String itemOrderState) {
		this.itemOrderState = itemOrderState;
	}
	public int getItemOrderDetailKey() {
		return itemOrderDetailKey;
	}
	public void setItemOrderDetailKey(int itemOrderDetailKey) {
		this.itemOrderDetailKey = itemOrderDetailKey;
	}
}
