package onedaybaking;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/DeleteClassServlet")
public class DeleteClassServlet extends HttpServlet {
    private getClassMgr getClassMgr;
    
    @Override
    public void init() throws ServletException {
        super.init();
        getClassMgr = new getClassMgr();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // 요청 파라미터 읽기
        String action = request.getParameter("action");
        int classKey = Integer.parseInt(request.getParameter("classkey"));
        
        // 클래스 삭제 작업 수행
        boolean deleteResult = getClassMgr.deleteClass(classKey);
        
        // 응답 작성
        response.setContentType("text/plain");
        if (deleteResult) {
            response.getWriter().write("Class deleted successfully.");
        } else {
            response.getWriter().write("Failed to delete class.");
        }
    }
}