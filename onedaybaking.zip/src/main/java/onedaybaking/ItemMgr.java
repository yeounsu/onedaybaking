package onedaybaking;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Vector;

public class ItemMgr {
	DBConnectionMgr pool;
	
	public ItemMgr() {
		pool = DBConnectionMgr.getInstance();
	}
	
	//특정 상품 정보 가져오기
	public ItemBean getItem(int key) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		ItemBean bean = new ItemBean();
		try {
			con = pool.getConnection();
			sql = "select * from item where itemkey = ?";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, key);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				bean.setItemkey(rs.getInt(1));
				bean.setItemname(rs.getString(2));
				bean.setItemdate(rs.getString(3));
				bean.setItemprice(rs.getInt(4));
				bean.setItemlocation(rs.getString(5));
				bean.setItemkeep(rs.getString(6));
				bean.setItemperiod(rs.getString(7));
				bean.setItemimg(rs.getString(9));
				bean.setItemimg1(rs.getString(10));
				bean.setItemimg2(rs.getString(11));
				bean.setItemimg3(rs.getString(12));
				bean.setItemimg4(rs.getString(13));
				bean.setItemcontent(rs.getString(14));
				bean.setMemberid(rs.getString(15));
				bean.setCategorykey(rs.getInt(16));
				MemberMgr mgr = new MemberMgr();
				MemberBean mbean = mgr.memberList(rs.getString(15));
				bean.setMembername(mbean.getMemberNick());
				bean.setMemberimg(mbean.getMemberInfoImg());
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt, rs);
		}
		return bean;
	}
	
	//상품 찜 여부
	public boolean isWishItem(String id, int itemkey) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		boolean flag = false;
		try {
			con = pool.getConnection();
			sql = "select * from wish where memberid = ? and itemkey = ?";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, id);
			pstmt.setInt(2, itemkey);
			rs = pstmt.executeQuery();
			if (rs.next()) flag = true;
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt, rs);
		}
		return flag;
	}
	
	//상품 전체 개수
	public int getTotalItemCount(String keyField, String keyWord, String sdate, String edate) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		int totalCount = 0;
		try {
			con = pool.getConnection();
			if (keyWord.trim().equals("") || keyWord == null) {
				if (sdate.trim().equals("") || sdate == null) {
					sql = "select count(*) from item";
					pstmt = con.prepareStatement(sql);
				} else {
					sql = "select count(*) from item where itemdate between ? and ?";
					pstmt = con.prepareStatement(sql);
					pstmt.setString(1, sdate);
					pstmt.setString(2, edate);
				}
			} else if (keyWord != null && sdate != null) {
				if (sdate.trim().equals("") || sdate == null) {
					if (keyField.equals("memberid")) {
						sql = "select count(*) from item where " + keyField + " = ?";
						pstmt = con.prepareStatement(sql);
						pstmt.setString(1, keyWord);
					} else {
						sql = "select count(*) from item a left outer join member b on a.memberid = b.memberid where " + keyField + " like ?";
						pstmt = con.prepareStatement(sql);
						pstmt.setString(1, "%" + keyWord + "%");
					}
				} else {
					sql = "select count(*) from item a left outer join member b on a.memberid = b.memberid where " + keyField + " = ?  and itemdate between ? and ?";
					pstmt = con.prepareStatement(sql);
					pstmt.setString(1, keyWord);
					pstmt.setString(2, sdate);
					pstmt.setString(3, edate);
				}
			}
			rs = pstmt.executeQuery();
			if (rs.next()) totalCount = rs.getInt(1);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt, rs);
		}
		return totalCount;
	}
	
	//관리자
	//상품 목록 가져오기 (
	public Vector<ItemBean> getAllProduct(String keyField, String keyWord, int start, int cnt, String sdate, String edate) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		Vector<ItemBean> vlist = new Vector<ItemBean>();
		try {
			con = pool.getConnection();
			if (keyWord.trim().equals("") || keyWord == null) {
				if (sdate.trim().equals("") || sdate == null) {
					sql = "select itemkey, b.membername, itemname, itemprice, a.memberid, itemdate, itemdelete from item a left outer join member b on a.memberid = b.memberid order by itemkey desc limit ?, ?";
					pstmt = con.prepareStatement(sql);
					pstmt.setInt(1, start);
					pstmt.setInt(2, cnt);
				} else {
					sql = "select itemkey, b.membername, itemname, itemprice, a.memberid, itemdate, itemdelete from item a left outer join member b on a.memberid = b.memberid where itemdate between ? and ? order by itemkey desc limit ?, ?";
					pstmt = con.prepareStatement(sql);
					pstmt.setString(1, sdate);
					pstmt.setString(2, edate);
					pstmt.setInt(3, start);
					pstmt.setInt(4, cnt);
				}
			} else if (keyWord != null && sdate != null) {
				if (sdate.trim().equals("") || sdate == null) {
					if (keyField.equals("memberid")) {
						sql = "select itemkey, b.membername, itemname, itemprice, a.memberid, itemdate, itemdelete from item a left outer join member b on a.memberid = b.memberid where " + keyField + " = ? order by itemkey desc limit ?, ?";
						pstmt = con.prepareStatement(sql);
						pstmt.setString(1, keyWord);
						pstmt.setInt(2, start);
						pstmt.setInt(3, cnt);
					} else {
						sql = "select itemkey, b.membername, itemname, itemprice, a.memberid, itemdate, itemdelete from item a left outer join member b on a.memberid = b.memberid where " + keyField + " like ? order by itemkey desc limit ?, ?";
						pstmt = con.prepareStatement(sql);
						pstmt.setString(1, "%" + keyWord + "%");
						pstmt.setInt(2, start);
						pstmt.setInt(3, cnt);
					}
				} else {
					sql = "select itemkey, b.membername, itemname, itemprice, a.memberid, itemdate, itemdelete from item a left outer join member b on a.memberid = b.memberid where " + keyField + " = ?  and itemdate between ? and ? order by itemkey desc limit ?, ?";
					pstmt = con.prepareStatement(sql);
					pstmt.setString(1, keyWord);
					pstmt.setString(2, sdate);
					pstmt.setString(3, edate);
					pstmt.setInt(4, start);
					pstmt.setInt(5, cnt);
				}
			}
			rs = pstmt.executeQuery();
			while (rs.next()) {
				ItemBean bean = new ItemBean();
				bean.setItemkey(rs.getInt("itemkey"));
				bean.setMembername(rs.getString("membername"));
				bean.setItemname(rs.getString("itemname"));
				bean.setItemprice(rs.getInt("itemprice"));
				bean.setMemberid(rs.getString("memberid"));
				bean.setItemdate(rs.getString("itemdate"));
				bean.setItemdelete(rs.getString("itemdelete"));
				vlist.addElement(bean);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt, rs);
		}
		return vlist;
	}
	
	//상품 삭제여부 바꾸기
	public boolean setItemDelete(int key) {
		Connection con = null;
		PreparedStatement pstmt = null;
		String sql = null;
		boolean flag = false;
		try {
			con = pool.getConnection();
			sql = "update item set itemdelete = 'Y' where itemkey = ?";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, key);
			if (pstmt.executeUpdate() == 1) flag = true;
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt);
		}
		return false;
	}
}