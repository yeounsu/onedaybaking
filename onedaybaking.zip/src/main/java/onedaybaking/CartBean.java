package onedaybaking;

public class CartBean {
	
	private int itemcartkey;
	private int itemkey;
	private String itemname;
	private String[] option;
	private int itemprice;
	private int itemcount;

	public int getItemcartkey() {
		return itemcartkey;
	}
	public void setItemcartkey(int itemcartkey) {
		this.itemcartkey = itemcartkey;
	}
	public int getItemkey() {
		return itemkey;
	}
	public void setItemkey(int itemkey) {
		this.itemkey = itemkey;
	}
	public String getItemname() {
		return itemname;
	}
	public void setItemname(String itemname) {
		this.itemname = itemname;
	}
	public String[] getOption() {
		return option;
	}
	public void setOption(String[] option) {
		this.option = option;
	}
	public int getItemprice() {
		return itemprice;
	}
	public void setItemprice(int itemprice) {
		this.itemprice = itemprice;
	}
	public int getItemcount() {
		return itemcount;
	}
	public void setItemcount(int itemcount) {
		this.itemcount = itemcount;
	}
}